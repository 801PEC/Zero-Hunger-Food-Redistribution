import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import 'leaflet/dist/leaflet.css'
import './style.css'
import { App } from './App'
import { ThemeProvider } from './lib/theme'

const el = document.querySelector<HTMLDivElement>('#app')
if (!el) throw new Error('Missing #app element')

ReactDOM.createRoot(el).render(
  <React.StrictMode>
    <ThemeProvider>
      <BrowserRouter>
        <App />
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              borderRadius: '14px',
              border: '1px solid rgba(255,255,255,0.09)',
              background: 'rgba(15,15,25,0.95)',
              color: '#e5e5e5',
              backdropFilter: 'blur(20px)',
              fontSize: '0.875rem',
              boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
            },
            success: {
              iconTheme: { primary: '#34d399', secondary: 'transparent' },
            },
            error: {
              iconTheme: { primary: '#f87171', secondary: 'transparent' },
            },
          }}
        />
      </BrowserRouter>
    </ThemeProvider>
  </React.StrictMode>,
)
