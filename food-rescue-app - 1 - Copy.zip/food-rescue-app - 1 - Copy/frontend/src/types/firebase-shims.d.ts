declare module 'firebase/app'
declare module 'firebase/auth'
declare module 'firebase/compat/app'
declare module 'firebase/compat/auth'

