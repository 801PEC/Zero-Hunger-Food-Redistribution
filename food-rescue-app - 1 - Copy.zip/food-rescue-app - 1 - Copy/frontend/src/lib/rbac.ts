import { doc, getDoc } from 'firebase/firestore'
import { db } from './firebase'

export type SignupRole = 'restaurant' | 'ngo'
export type UserRole = 'restaurant' | 'ngo' | 'admin'

export function getDashboardPathByRole(role: UserRole) {
  if (role === 'restaurant') return '/restaurant'
  if (role === 'ngo') return '/ngo'
  return '/admin'
}

export async function getUserRole(uid: string): Promise<UserRole | null> {
  const ref = doc(db, 'users', uid)
  const snap = await getDoc(ref)
  if (!snap.exists()) return null
  const role = snap.data()?.role
  if (role === 'restaurant' || role === 'ngo' || role === 'admin') return role
  return null
}

