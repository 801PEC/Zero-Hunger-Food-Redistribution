import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'
const firebaseConfig = {
  apiKey: "AIzaSyDWiWZKP-1Ad7gOAMEH9llmHz32WsMdiGU",
  authDomain: "foodrescue-32ca4.firebaseapp.com",
  projectId: "foodrescue-32ca4",
  storageBucket: "foodrescue-32ca4.firebasestorage.app",
  messagingSenderId: "141090750452",
  appId: "1:141090750452:web:35aa5d219a9a7f3db983a1"
};

export const firebaseApp = initializeApp(firebaseConfig)
export const auth = getAuth(firebaseApp)
export const db = getFirestore(firebaseApp)
