import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { TopNavbarLayout } from '../layout/TopNavbarLayout'
import { onAuthStateChanged } from 'firebase/auth'
import { collection, query, where, onSnapshot, doc, updateDoc, getDoc } from 'firebase/firestore'
import { auth, db } from '../../lib/firebase'
import toast from 'react-hot-toast'

type Props = {
  children: ReactNode
  title: string
}

const navItems = [
  { label: 'Post Food', to: '/restaurant', end: true },
  { label: 'My Dashboard', to: '/restaurant/dashboard' },
  { label: 'My Posts', to: '/restaurant/posts' },
  { label: 'Profile', to: '/restaurant/profile' },
]

export function RestaurantSidebarLayout({ children, title }: Props) {
  const [uid, setUid] = useState<string | null>(null)
  const [justClaimedPost, setJustClaimedPost] = useState<any | null>(null)

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user: any) => setUid(user ? user.uid : null))
    return () => unsub()
  }, [])

  useEffect(() => {
    if (!uid) return
    const q = query(
      collection(db, 'foodPosts'),
      where('restaurantId', '==', uid),
      where('status', '==', 'claimed')
    )
    const unsub = onSnapshot(q, async (snap) => {
      let found = null
      for (const d of snap.docs) {
        const post = { id: d.id, ...d.data() } as any
        if (!post.restaurantNotifiedOfClaim) {
          found = post
          break
        }
      }

      if (found && found.acceptedBy) {
        try {
           const userSnap = await getDoc(doc(db, 'users', found.acceptedBy));
           if (userSnap.exists()) {
               found.ngoName = userSnap.data().ngoName || userSnap.data().name || 'An NGO';
           } else {
               found.ngoName = 'An NGO';
           }
        } catch(e) {
           found.ngoName = 'An NGO';
        }
      }

      setJustClaimedPost(found)
    })
    return () => unsub()
  }, [uid])

  async function acknowledgeNotification() {
    if (!justClaimedPost) return
    try {
      await updateDoc(doc(db, 'foodPosts', justClaimedPost.id), {
        restaurantNotifiedOfClaim: true
      })
      setJustClaimedPost(null)
    } catch(e) {
      toast.error('Failed to clear notification')
    }
  }

  return (
    <TopNavbarLayout title={title} logoLabel="Restaurant" navItems={navItems}>
      {/* 🎉 Food Claimed Notification */}
      {justClaimedPost && (
        <div className="fixed inset-x-0 top-20 z-[9999] mx-auto w-full max-w-sm px-4">
          <div className="glass-notification animate-fade-up">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-base font-bold text-white">
                <span className="text-lg">🎉</span> Food Claimed!
              </h3>
              <span className="badge badge-green">New</span>
            </div>
            <p className="text-sm text-white/60 leading-relaxed">
              <strong className="font-semibold text-emerald-400">{justClaimedPost.ngoName}</strong>{' '}
              has accepted your post for{' '}
              <strong className="text-white/85">{justClaimedPost.foodName}</strong>{' '}
              ({justClaimedPost.quantity})!<br />
              They are on their way to pick it up.
            </p>
            <div className="mt-4">
              <button
                onClick={acknowledgeNotification}
                className="cta-btn w-full py-2.5 text-sm"
                style={{
                  background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
                  boxShadow: '0 4px 16px rgba(5, 150, 105, 0.35)',
                }}
              >
                Awesome! Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
      {children}
    </TopNavbarLayout>
  )
}
