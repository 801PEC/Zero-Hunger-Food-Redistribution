type SpinnerProps = {
  size?: 'sm' | 'md'
  tone?: 'light' | 'dark'
}

export function Spinner({ size = 'md', tone = 'dark' }: SpinnerProps) {
  const sizeClass = size === 'sm' ? 'h-4 w-4 border-2' : 'h-6 w-6 border-[3px]'
  const colorClass =
    tone === 'light'
      ? 'border-white/25 border-t-white'
      : 'border-white/10 border-t-purple-500'

  return (
    <span
      className={`inline-block animate-spin rounded-full ${sizeClass} ${colorClass}`}
      aria-label="Loading"
      role="status"
    />
  )
}

