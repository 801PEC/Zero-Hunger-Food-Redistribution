import type { ReactNode } from 'react'
import { TopNavbarLayout } from '../layout/TopNavbarLayout'

type Props = {
  children: ReactNode
  title: string
}

const adminNavItems = [
  { label: 'Overview', to: '/admin', end: true },
  { label: 'All Posts', to: '/admin/posts' },
  { label: 'All Users', to: '/admin/users' },
]

export function AdminTopNavbarLayout({ children, title }: Props) {
  return (
    <TopNavbarLayout title={title} logoLabel="Admin" navItems={adminNavItems}>
      {children}
    </TopNavbarLayout>
  )
}

