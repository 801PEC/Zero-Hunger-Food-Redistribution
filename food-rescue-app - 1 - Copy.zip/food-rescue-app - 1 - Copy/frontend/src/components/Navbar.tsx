import { onAuthStateChanged, signOut } from 'firebase/auth'
import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { HiMenu, HiX } from 'react-icons/hi'
import logo from '../assets/logo.png'
import { auth } from '../lib/firebase'
import { type SignupRole, getUserRole } from '../lib/rbac'

type NavbarProps = {
  title?: string
  showLogout?: boolean
}

export function Navbar({ title: _title = 'Zero Hunger', showLogout = false }: NavbarProps) {
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const [role, setRole] = useState<SignupRole | null>(null)

  async function onLogout() {
    await signOut(auth)
    navigate('/')
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        setRole(null)
        return
      }
      const userRole = await getUserRole(user.uid)
      if (userRole === 'restaurant' || userRole === 'ngo') {
        setRole(userRole)
      } else {
        setRole(null)
      }
    })
    return () => unsub()
  }, [])

  const roleLinks =
    role === 'restaurant'
      ? [{ label: 'Restaurant', to: '/restaurant' }]
      : role === 'ngo'
        ? [
            { label: 'NGO', to: '/ngo' },
            { label: 'My Activity', to: '/ngo/activity' },
          ]
        : [{ label: 'Home', to: '/' }]
  const links = [...roleLinks, { label: 'Contact', to: '/contact' }]

  return (
    <header className="glass-navbar sticky top-0 z-20">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <Link to="/" className="flex items-center gap-2">
          <img
            src={logo}
            alt="Zero Hunger"
            className="h-8 w-auto shrink-0 object-contain dark:invert-0 brightness-110"
          />
        </Link>

        <nav className="hidden items-center gap-2 md:flex">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-white/80 hover:text-slate-900 dark:text-[#94a3b8] dark:hover:bg-white/10 dark:hover:text-[#f1f5f9]"
            >
              {link.label}
            </Link>
          ))}
          {showLogout ? (
            <button
              type="button"
              onClick={() => void onLogout()}
              className="rounded-lg bg-[#ea580c] px-3 py-2 text-sm font-semibold text-white transition hover:bg-orange-700"
            >
              Logout
            </button>
          ) : null}
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="rounded-lg border border-white/80 bg-white/70 p-2 text-slate-700 dark:border-white/10 dark:bg-white/8 dark:text-[#f1f5f9] md:hidden"
        >
          {open ? <HiX className="h-5 w-5" /> : <HiMenu className="h-5 w-5" />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-white/70 bg-white/75 px-4 py-3 backdrop-blur-md dark:border-white/10 dark:bg-white/5 md:hidden">
          <div className="flex flex-col gap-2">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium text-slate-700 hover:bg-white/90 dark:text-[#94a3b8] dark:hover:bg-white/10 dark:hover:text-[#f1f5f9]"
              >
                {link.label}
              </Link>
            ))}
            {showLogout ? (
              <button
                type="button"
                onClick={() => void onLogout()}
                className="rounded-lg bg-[#ea580c] px-3 py-2 text-sm font-semibold text-white"
              >
                Logout
              </button>
            ) : null}
          </div>
        </div>
      ) : null}
    </header>
  )
}

