import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { TopNavbarLayout } from '../layout/TopNavbarLayout'
import { onAuthStateChanged } from 'firebase/auth'
import { collection, query, where, onSnapshot, doc, updateDoc, arrayUnion } from 'firebase/firestore'
import { auth, db } from '../../lib/firebase'
import toast from 'react-hot-toast'

type Props = {
  children: ReactNode
  title: string
}

const ngoNavItems = [
  { label: '🗺️ Food Map', to: '/ngo', end: true },
  { label: '📊 My Activity', to: '/ngo/activity' },
  { label: '👤 Profile', to: '/ngo/profile' },
]

export function NGOSidebarLayout({ children, title }: Props) {
  const [uid, setUid] = useState<string | null>(null)
  const [urgentPost, setUrgentPost] = useState<any | null>(null)
  const [takingAction, setTakingAction] = useState(false)

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user: any) => setUid(user ? user.uid : null))
    return () => unsub()
  }, [])

  useEffect(() => {
    if (!uid) return
    console.log('[NGOSidebarLayout] Listening for assignments to:', uid)
    const q = query(
      collection(db, 'foodPosts'),
      where('status', '==', 'available'),
      where('assignedNgoId', '==', uid)
    )
    const unsub = onSnapshot(q, (snap) => {
      console.log('[NGOSidebarLayout] Snapshot received. Size:', snap.size)
      let found = null
      for (const d of snap.docs) {
        const post = { id: d.id, ...d.data() } as any
        if (post.assignmentExpiresAt) {
          // Fix: Support both Timestamp and String
          const expiryDate = post.assignmentExpiresAt?.toDate 
             ? post.assignmentExpiresAt.toDate() 
             : new Date(post.assignmentExpiresAt)
             
          const expiresMs = expiryDate.getTime()
          if (!isNaN(expiresMs) && expiresMs > Date.now()) {
            console.log('[NGOSidebarLayout] Valid assigned post found:', post.foodName)
            found = post
            break
          }
        }
      }
      setUrgentPost(found)
    })
    return () => unsub()
  }, [uid])


  async function acceptPost() {
    if (!urgentPost || !uid) return
    setTakingAction(true)
    try {
      await updateDoc(doc(db, 'foodPosts', urgentPost.id), {
        status: 'claimed',
        acceptedBy: uid,
        claimedBy: uid,
        acceptedAt: new Date().toISOString()
      })
      toast.success('You have claimed the food!')
      setUrgentPost(null)
    } catch (e) {
      toast.error('Failed to claim post')
    } finally {
      setTakingAction(false)
    }
  }

  async function declinePost() {
    if (!urgentPost || !uid) return
    setTakingAction(true)
    try {
      const declinedList = Array.isArray(urgentPost.declinedByNgos) ? [...urgentPost.declinedByNgos, uid] : [uid]
      
      const matchRes = await fetch(`${import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'}/api/match`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            foodPost: {
              ...urgentPost,
              declinedByNgos: declinedList
            }
          }),
        })
        
      let nextNgoId = null
      let newExpiry = null
      if (matchRes.ok) {
           const matchData = await matchRes.json()
           if (matchData.bestNgo?.id && matchData.bestNgo.id !== uid) {
               nextNgoId = matchData.bestNgo.id;
               const expiry = new Date();
               expiry.setMinutes(expiry.getMinutes() + 15);
               newExpiry = expiry.toISOString()
           }
      }

      await updateDoc(doc(db, 'foodPosts', urgentPost.id), {
        declinedByNgos: arrayUnion(uid),
        assignedNgoId: nextNgoId || 'public',
        assignmentExpiresAt: newExpiry
      })
      toast.success('Passed to next NGO')
      setUrgentPost(null)
    } catch (e) {
        toast.error('Error passing post')
    } finally {
      setTakingAction(false)
    }
  }

  return (
    <TopNavbarLayout title={title} logoLabel="NGO" navItems={ngoNavItems}>
      {/* 🤖 Smart Match Notification */}
      {urgentPost && (
        <div className="fixed inset-x-0 bottom-6 z-[9999] mx-auto w-full max-w-sm px-4">
          <div className="glass-notification animate-fade-up">
            <div className="mb-3 flex items-center justify-between">
              <h3 className="flex items-center gap-2 font-bold text-white">
                <span className="relative flex h-3 w-3">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-purple-400 opacity-75" />
                  <span className="relative inline-flex h-3 w-3 rounded-full bg-purple-500" />
                </span>
                Smart Match!
              </h3>
              <span className="badge badge-purple">Exclusive</span>
            </div>
            <p className="text-sm text-white/60 leading-relaxed">
              You are the best match for{' '}
              <strong className="text-white/90">{urgentPost.foodName}</strong>{' '}
              ({urgentPost.quantity}).
              {urgentPost.riskLevel === 'CRITICAL' && (
                <span className="mt-1 block font-bold text-red-400">🚨 Urgent AI Warning!</span>
              )}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                onClick={acceptPost}
                disabled={takingAction}
                className="cta-btn py-2.5 text-sm disabled:opacity-50"
              >
                Accept Match
              </button>
              <button
                onClick={declinePost}
                disabled={takingAction}
                className="soft-btn py-2.5 text-sm disabled:opacity-50"
              >
                Pass to Next
              </button>
            </div>
          </div>
        </div>
      )}
      {children}
    </TopNavbarLayout>
  )
}
