import { signOut } from 'firebase/auth'
import type { ReactNode } from 'react'
import { useState } from 'react'
import { HiMenu, HiX } from 'react-icons/hi'
import { FiSun, FiMoon } from 'react-icons/fi'
import { NavLink, useNavigate } from 'react-router-dom'
import { auth } from '../../lib/firebase'
import { useTheme } from '../../lib/theme'
import logo from '../../assets/logo.png'

type NavItem = {
  label: string
  to: string
  end?: boolean
}

type Props = {
  children: ReactNode
  title: string
  logoLabel: string
  navItems: NavItem[]
}

export function TopNavbarLayout({ children, title, logoLabel, navItems }: Props) {
  const navigate = useNavigate()
  const [open, setOpen] = useState(false)
  const { theme, toggleTheme } = useTheme()

  async function onLogout() {
    await signOut(auth)
    navigate('/login')
  }

  return (
    <div className="glass-page min-h-screen">
      <header className="glass-navbar sticky top-0 z-20">
        <div className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between px-4 sm:px-6">
          {/* Logo */}
          <NavLink to="/" className="flex items-center gap-2.5 group">
            <div className="relative h-8 w-8 shrink-0">
              <div className="absolute inset-0 rounded-full bg-purple-600/20 blur-md group-hover:bg-purple-500/30 transition-all duration-300" />
              <img src={logo} alt="Zero Hunger" className="relative h-8 w-8 object-contain" />
            </div>
            <div>
              <div className="text-sm font-bold text-white leading-tight">Zero Hunger</div>
              <div className="text-[10px] font-medium text-purple-400/80 leading-tight">{logoLabel}</div>
            </div>
          </NavLink>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-1 md:flex">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  isActive ? 'nav-link active' : 'nav-link'
                }
              >
                {item.label}
              </NavLink>
            ))}
            <NavLink
              to="/contact"
              className={({ isActive }) =>
                isActive ? 'nav-link active' : 'nav-link'
              }
            >
              Contact
            </NavLink>
          </nav>

          {/* Desktop controls */}
          <div className="hidden items-center gap-2 md:flex">
            <button
              type="button"
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="rounded-lg border border-white/08 bg-white/05 p-2 text-white/60 hover:text-white hover:bg-white/10 hover:border-white/15 transition-all duration-200"
            >
              {theme === 'dark' ? <FiSun className="h-4 w-4" /> : <FiMoon className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={() => void onLogout()}
              className="rounded-lg border border-red-500/25 bg-red-500/10 px-3 py-2 text-sm font-semibold text-red-400 hover:bg-red-500/20 hover:border-red-400/40 hover:text-red-300 transition-all duration-200"
            >
              Logout
            </button>
          </div>

          {/* Mobile hamburger */}
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="rounded-lg border border-white/08 bg-white/05 p-2 text-white/70 md:hidden hover:bg-white/10 transition-all duration-200"
          >
            {open ? <HiX className="h-5 w-5" /> : <HiMenu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile drawer */}
        {open && (
          <div className="border-t border-white/06 bg-[rgba(11,11,15,0.92)] px-4 py-3 backdrop-blur-xl md:hidden">
            <div className="flex flex-col gap-1.5">
              <button
                type="button"
                onClick={toggleTheme}
                className="inline-flex items-center gap-2 rounded-lg border border-white/08 bg-white/05 px-3 py-2.5 text-sm font-medium text-white/70 hover:text-white hover:bg-white/10 transition-all"
              >
                {theme === 'dark' ? <FiSun className="h-4 w-4" /> : <FiMoon className="h-4 w-4" />}
                {theme === 'dark' ? 'Light mode' : 'Dark mode'}
              </button>
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    isActive ? 'nav-link active' : 'nav-link'
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              <NavLink
                to="/contact"
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  isActive ? 'nav-link active' : 'nav-link'
                }
              >
                Contact
              </NavLink>
              <button
                type="button"
                onClick={() => void onLogout()}
                className="rounded-lg border border-red-500/25 bg-red-500/10 px-3 py-2.5 text-sm font-semibold text-red-400 hover:bg-red-500/18 text-left transition-all duration-200"
              >
                Logout
              </button>
            </div>
          </div>
        )}
      </header>

      <main className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6">
        <h1 className="mb-6 text-2xl font-bold text-white/90">{title}</h1>
        {children}
      </main>
    </div>
  )
}
