import { signOut } from 'firebase/auth'
import type { ReactNode } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { auth } from '../../lib/firebase'

type NavItem = {
  label: string
  to: string
  end?: boolean
}

type Props = {
  children: ReactNode
  title: string
  sectionLabel: string
  navItems: NavItem[]
}

export function RoleSidebarLayout({ children, title, sectionLabel, navItems }: Props) {
  const navigate = useNavigate()

  async function onLogout() {
    await signOut(auth)
    navigate('/login')
  }

  return (
    <div className="min-h-screen bg-[#f9fafb] md:grid md:grid-cols-[250px_1fr]">
      <aside className="border-r border-slate-200 bg-white p-4 shadow-lg">
        <div className="mb-6 flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-lg bg-[#16a34a] text-sm font-bold text-white">
            FB
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-900">Zero Hunger</div>
            <div className="text-xs text-slate-500">{sectionLabel}</div>
          </div>
        </div>

        <nav className="space-y-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                [
                  'block rounded-xl px-3 py-2 text-sm font-medium transition-all duration-200 ease-in-out',
                  isActive
                    ? 'bg-green-100 text-[#16a34a]'
                    : 'text-slate-700 hover:bg-slate-100 hover:-translate-y-0.5',
                ].join(' ')
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-8 border-t border-slate-200 pt-4">
          <button
            type="button"
            onClick={() => void onLogout()}
            className="w-full rounded-xl bg-[#ea580c] px-3 py-2 text-sm font-semibold text-white transition-all duration-200 ease-in-out hover:-translate-y-0.5 hover:bg-orange-700"
          >
            Logout
          </button>
        </div>
      </aside>

      <main className="p-4 sm:p-6">
        <h1 className="mb-4 text-2xl font-bold text-slate-900">{title}</h1>
        {children}
      </main>
    </div>
  )
}

