import { onAuthStateChanged } from 'firebase/auth'
import { collection, getDocs, doc, updateDoc } from 'firebase/firestore'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { FaUserCircle, FaShieldAlt, FaTrashAlt, FaSearch } from 'react-icons/fa'
import { AdminTopNavbarLayout } from '../components/admin/AdminTopNavbarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type AppUser = {
  id: string
  email?: string
  role?: string
  name?: string
  ngoName?: string
}

export function AdminUsersPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [users, setUsers] = useState<AppUser[]>([])
  const [search, setSearch] = useState('')

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        navigate('/')
        return
      }
      try {
        setLoading(true)
        const snap = await getDocs(collection(db, 'users'))
        setUsers(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<AppUser, 'id'>) })))
      } catch (err) {
        toast.error('Failed to load user database')
      } finally {
        setLoading(false)
      }
    })
    return () => unsub()
  }, [navigate])

  const filteredUsers = users.filter(u => 
    (u.name || '').toLowerCase().includes(search.toLowerCase()) || 
    (u.email || '').toLowerCase().includes(search.toLowerCase()) ||
    (u.ngoName || '').toLowerCase().includes(search.toLowerCase())
  )

  const toggleAdmin = async (user: AppUser) => {
    const newRole = user.role === 'admin' ? 'restaurant' : 'admin' // Simple toggle for demo
    try {
      await updateDoc(doc(db, 'users', user.id), { role: newRole })
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, role: newRole } : u))
      toast.success(`${user.name} role updated to ${newRole}`)
    } catch (err) {
      toast.error('Failed to update role')
    }
  }

  return (
    <AdminTopNavbarLayout title="User Manifest">
      <div className="mx-auto w-full max-w-7xl space-y-6 pb-10">
        
        {/* Search Header */}
        <div className="flex items-center justify-between gap-4">
           <div className="relative max-w-md w-full">
              <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" />
              <input 
                type="text"
                placeholder="Find users by name, email or org..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="glass-input pl-11"
              />
           </div>
           <div className="hidden sm:flex items-center gap-3">
              <div className="glass-stats-card px-4 py-2 text-[10px] font-bold uppercase tracking-widest text-white/40">
                 System Capacity: <span className="text-emerald-400">UNLIMITED</span>
              </div>
           </div>
        </div>

        {loading ? (
          <div className="card-surface p-12 text-center">
            <Spinner />
            <p className="mt-4 text-sm text-white/30 tracking-widest uppercase font-bold">Decrypting User Data...</p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
             {filteredUsers.map((user) => (
                <div key={user.id} className="card-surface group p-5 border-l-2 border-transparent hover:border-purple-500/50 transition-all">
                   <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 rounded-full bg-white/05 flex items-center justify-center text-white/20 group-hover:text-purple-400 transition-colors">
                           <FaUserCircle size={24} />
                        </div>
                        <div>
                           <h4 className="font-bold text-white/90 leading-tight">{user.name || user.ngoName || 'Anonymous User'}</h4>
                           <p className="text-[10px] text-white/30 truncate max-w-[160px]">{user.email}</p>
                        </div>
                      </div>
                      <span className={`badge ${
                         user.role === 'admin' ? 'badge-purple' : user.role === 'ngo' ? 'badge-blue' : 'badge-green'
                      }`}>
                         {user.role || 'user'}
                      </span>
                   </div>

                   <div className="mt-6 flex items-center justify-between gap-2">
                       <button 
                         onClick={() => toggleAdmin(user)}
                         className="flex-1 soft-btn py-2 text-[10px] uppercase font-bold tracking-widest"
                       >
                          <FaShieldAlt className="mr-1.5" /> {user.role === 'admin' ? 'Demote' : 'Make Admin'}
                       </button>
                       <button className="p-2 rounded-xl bg-red-500/10 text-red-500/40 hover:text-red-500 hover:bg-red-500/20 transition-all">
                          <FaTrashAlt size={12} />
                       </button>
                   </div>
                </div>
             ))}
             {filteredUsers.length === 0 && (
                <div className="col-span-full py-20 text-center card-surface">
                   <p className="text-white/20 uppercase tracking-[0.3em] font-black text-xs">No Nodes Found</p>
                </div>
             )}
          </div>
        )}
      </div>
    </AdminTopNavbarLayout>
  )
}
