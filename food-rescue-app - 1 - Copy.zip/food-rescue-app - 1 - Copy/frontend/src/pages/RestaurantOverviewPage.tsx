import { onAuthStateChanged } from 'firebase/auth'
import { collection, getDocs, query, where } from 'firebase/firestore'
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { RestaurantSidebarLayout } from '../components/restaurant/RestaurantSidebarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type Post = {
  id: string
  foodName: string
  quantity: string
  status?: string
  expiryTime: string
  createdAt?: { seconds?: number }
}

function parseMeals(quantity: string) {
  const match = quantity?.match(/(\d+(\.\d+)?)/)
  if (!match) return 1
  const n = Number(match[1])
  return Number.isNaN(n) ? 1 : n
}

function postStatus(post: Post) {
  const expiry = new Date(post.expiryTime).getTime()
  if (!Number.isNaN(expiry) && expiry < Date.now()) return 'expired'
  if (post.status === 'collected') return 'collected'
  if (post.status === 'claimed') return 'claimed'
  return 'available'
}

function statusColor(s: string) {
  if (s === 'available') return 'badge badge-green'
  if (s === 'claimed')   return 'badge badge-amber'
  if (s === 'collected') return 'badge badge-purple'
  return 'badge badge-slate'
}

export function RestaurantOverviewPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [posts, setPosts] = useState<Post[]>([])
  const [feedbacks, setFeedbacks] = useState<any[]>([])

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        navigate('/login')
        return
      }
      setLoading(true)
      const snap = await getDocs(query(collection(db, 'foodPosts'), where('restaurantId', '==', user.uid)))
      const items: Post[] = snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<Post, 'id'>) }))
      setPosts(items)

      try {
        const fSnap = await getDocs(query(collection(db, 'restaurantFeedbacks'), where('restaurantId', '==', user.uid)))
        setFeedbacks(fSnap.docs.map(d => ({ id: d.id, ...d.data() })))
      } catch(e) {
        // Feedbacks might not exist yet or lack index
      }

      setLoading(false)
    })
    return () => unsub()
  }, [navigate])

  const stats = useMemo(() => {
    const total = posts.length
    const meals = posts.reduce((sum, p) => sum + parseMeals(p.quantity), 0)
    const claimed = posts.filter((p) => ['claimed', 'collected'].includes(postStatus(p))).length
    const active = posts.filter((p) => postStatus(p) === 'available').length
    return { total, meals, claimed, active }
  }, [posts])

  const feedbackStats = useMemo(() => {
    if (!feedbacks.length) return { avg: 0, count: 0 }
    const sum = feedbacks.reduce((acc, f) => acc + (f.rating || 0), 0)
    return { avg: (sum / feedbacks.length).toFixed(1), count: feedbacks.length }
  }, [feedbacks])

  const recent = [...posts]
    .sort((a, b) => (b.createdAt?.seconds ?? 0) - (a.createdAt?.seconds ?? 0))
    .slice(0, 5)

  const statCards = [
    { label: 'Total Posted', value: stats.total,   color: 'text-purple-400', icon: '📦' },
    { label: 'Meals Donated', value: stats.meals,  color: 'text-blue-400',   icon: '🍽️' },
    { label: 'Claimed',    value: stats.claimed,   color: 'text-amber-400',  icon: '✅' },
    { label: 'Active ',    value: stats.active,    color: 'text-emerald-400',icon: '🟢' },
    {
      label: 'Avg Rating',
      value: feedbackStats.count ? `${feedbackStats.avg} ⭐` : 'N/A',
      color: 'text-yellow-400',
      icon: '⭐',
    },
  ]

  return (
    <RestaurantSidebarLayout title="My Dashboard">
      {loading ? (
        <div className="flex items-center gap-3 p-4">
          <Spinner size="sm" />
          <span className="text-sm text-white/50">Loading dashboard...</span>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Stat Cards */}
          <div className="grid gap-4 md:grid-cols-5">
            {statCards.map((s) => (
              <div key={s.label} className="glass-stats-card p-5">
                <div className="text-2xl mb-1">{s.icon}</div>
                <div className="text-xs font-semibold uppercase tracking-wide text-white/35">{s.label}</div>
                <div className={`mt-1.5 text-2xl font-bold ${s.color}`}>{s.value}</div>
              </div>
            ))}
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            {/* Recent Posts */}
            <section className="card-surface p-5">
              <h2 className="text-base font-semibold text-white/80 mb-4">Recent Posts</h2>
              {recent.length === 0 ? (
                <p className="text-sm text-white/35">No posts yet.</p>
              ) : (
                <div className="space-y-3">
                  {recent.map((p) => (
                    <div
                      key={p.id}
                      className="flex items-center justify-between rounded-xl border border-white/06 bg-white/03 px-4 py-3"
                    >
                      <div>
                        <div className="font-medium text-white/80 text-sm">{p.foodName}</div>
                        <div className="text-xs text-white/40">{p.quantity}</div>
                      </div>
                      <span className={statusColor(postStatus(p))}>{postStatus(p)}</span>
                    </div>
                  ))}
                </div>
              )}
            </section>

            {/* Impact */}
            <section className="card-surface p-5">
              <h2 className="text-base font-semibold text-white/80 mb-4">Impact 🌍</h2>
              <div className="flex flex-col gap-3">
                <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/08 p-4">
                  <div className="text-xs text-white/40 uppercase tracking-wide mb-1">Meals saved</div>
                  <div className="text-3xl font-bold text-emerald-400">{stats.meals}</div>
                  <div className="mt-1 text-xs text-white/40">across {stats.claimed} successful pickups</div>
                </div>
              </div>
            </section>
          </div>

          {/* NGO Feedback */}
          <section className="card-surface p-5">
            <h2 className="text-base font-semibold text-white/80 mb-4">NGO Feedback</h2>
            {feedbacks.length === 0 ? (
              <p className="text-sm text-white/35">No feedback received yet.</p>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {feedbacks.slice(0, 4).map(f => (
                  <div
                    key={f.id}
                    className="rounded-xl border border-white/06 bg-white/03 p-4"
                  >
                    <div className="text-yellow-400 text-sm">
                      {'★'.repeat(f.rating)}{'☆'.repeat(5 - f.rating)}
                    </div>
                    {f.comment && (
                      <p className="mt-1.5 text-xs text-white/45 italic">"{f.comment}"</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </RestaurantSidebarLayout>
  )
}
