import emailjs from '@emailjs/browser'
import type { FormEvent } from 'react'
import { useRef, useState } from 'react'
import { FiMoon, FiSun } from 'react-icons/fi'
import { Link } from 'react-router-dom'
import { Spinner } from '../components/Spinner'
import { useTheme } from '../lib/theme'

const SUBJECT_OPTIONS = ['General Inquiry', 'Partnership', 'Report Issue', 'Other'] as const

export function ContactUs() {
  const formRef = useRef<HTMLFormElement>(null)
  const [sending, setSending] = useState(false)
  const [feedback, setFeedback] = useState<'idle' | 'success' | 'error'>('idle')
  const { theme, toggleTheme } = useTheme()

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!formRef.current) return

    setFeedback('idle')
    setSending(true)
    try {
      await emailjs.sendForm(
        import.meta.env.VITE_EMAILJS_SERVICE_ID,
        import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
        formRef.current,
        import.meta.env.VITE_EMAILJS_PUBLIC_KEY,
      )
      setFeedback('success')
      formRef.current.reset()
    } catch {
      setFeedback('error')
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="glass-page min-h-screen px-4 py-12 sm:py-16">
      <main className="mx-auto w-full max-w-lg">
        {/* Top bar */}
        <div className="mb-6 flex items-center justify-between">
          <Link
            to="/"
            className="text-sm font-medium text-purple-400 hover:text-purple-300 transition-colors"
          >
            ← Back to home
          </Link>
          <button
            type="button"
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="rounded-lg border border-white/08 bg-white/04 p-2 text-white/50 hover:text-white hover:bg-white/10 transition-all"
          >
            {theme === 'dark' ? <FiSun className="h-4 w-4" /> : <FiMoon className="h-4 w-4" />}
          </button>
        </div>

        {/* Card */}
        <section
          className="animate-fade-up"
          style={{
            borderRadius: 20,
            border: '1px solid rgba(255,255,255,0.08)',
            background: 'rgba(255,255,255,0.04)',
            boxShadow: '0 24px 48px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.07)',
            backdropFilter: 'blur(24px)',
            WebkitBackdropFilter: 'blur(24px)',
            padding: '32px',
          }}
        >
          <h1 className="text-2xl font-bold text-white">Contact us</h1>
          <p className="mt-1 text-sm text-white/45">
            Send us a message — we&apos;ll get back to you as soon as we can.
          </p>

          <form ref={formRef} onSubmit={(e) => void handleSubmit(e)} className="mt-6 space-y-4">
            <label className="block">
              <span className="text-xs font-semibold uppercase tracking-wide text-white/40">Full name</span>
              <input
                name="name"
                type="text"
                required
                autoComplete="name"
                className="glass-input mt-1.5"
                placeholder="Your name"
              />
            </label>

            <label className="block">
              <span className="text-xs font-semibold uppercase tracking-wide text-white/40">Email address</span>
              <input
                name="email"
                type="email"
                required
                autoComplete="email"
                className="glass-input mt-1.5"
                placeholder="you@example.com"
              />
            </label>

            <label className="block">
              <span className="text-xs font-semibold uppercase tracking-wide text-white/40">Subject</span>
              <select
                name="title"
                required
                className="glass-input mt-1.5"
                defaultValue=""
                style={{ appearance: 'none' }}
              >
                <option value="" disabled style={{ background: '#0b0b0f' }}>
                  Select a subject
                </option>
                {SUBJECT_OPTIONS.map((opt) => (
                  <option key={opt} value={opt} style={{ background: '#0b0b0f' }}>
                    {opt}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="text-xs font-semibold uppercase tracking-wide text-white/40">Message</span>
              <textarea
                name="message"
                required
                rows={5}
                className="glass-input mt-1.5 resize-y"
                placeholder="How can we help?"
              />
            </label>

            {feedback === 'success' && (
              <p className="rounded-xl border border-emerald-500/25 bg-emerald-500/10 px-4 py-2.5 text-sm text-emerald-400" role="status">
                ✅ Message sent successfully!
              </p>
            )}
            {feedback === 'error' && (
              <p className="rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-2.5 text-sm text-red-400" role="alert">
                ❌ Failed to send. Try again.
              </p>
            )}

            <button
              type="submit"
              disabled={sending}
              className="cta-btn w-full py-3 text-sm gap-2 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {sending ? (
                <>
                  <Spinner size="sm" tone="light" />
                  Sending…
                </>
              ) : (
                'Send message'
              )}
            </button>
          </form>
        </section>
      </main>
    </div>
  )
}
