import { onAuthStateChanged } from 'firebase/auth'
import { collection, doc, getDocs, query, updateDoc, where } from 'firebase/firestore'
import { useEffect, useMemo, useState } from 'react'
import toast from 'react-hot-toast'
import { auth, db } from '../lib/firebase'
import { NGOSidebarLayout } from '../components/ngo/NGOSidebarLayout'
import { Spinner } from '../components/Spinner'
import { useNavigate } from 'react-router-dom'

type AcceptedPost = {
  id: string
  foodName: string
  quantity: string
  pickupAddress: string
  acceptedAt?: string
  claimedAt?: { seconds?: number; nanoseconds?: number }
  status?: string
  restaurantId?: string
}

function parseMeals(quantity: string) {
  const match = quantity?.match(/(\d+(\.\d+)?)/)
  if (!match) return 1
  const n = Number(match[1])
  return Number.isNaN(n) ? 1 : n
}

export function NgoActivityPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [posts, setPosts] = useState<AcceptedPost[]>([])
  const [updatingId, setUpdatingId] = useState<string | null>(null)
  const [feedbackModal, setFeedbackModal] = useState<{ isOpen: boolean; postId: string; restaurantId?: string } | null>(null)
  const [rating, setRating] = useState(5)
  const [feedbackText, setFeedbackText] = useState('')

  async function loadActivity(currentUid: string) {
    setLoading(true)
    try {
      const q = query(collection(db, 'foodPosts'), where('acceptedBy', '==', currentUid))
      const snap = await getDocs(q)
      const items: AcceptedPost[] = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<AcceptedPost, 'id'>),
      }))
      setPosts(items)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to load activity')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user: any) => {
      if (!user) {
        navigate('/login')
        return
      }
      void loadActivity(user.uid)
    })
    return () => unsub()
  }, [navigate])

  function openFeedbackModal(postId: string, restaurantId?: string) {
    setFeedbackModal({ isOpen: true, postId, restaurantId })
    setRating(5)
    setFeedbackText('')
  }

  async function markCollected() {
    if (!feedbackModal) return
    setUpdatingId(feedbackModal.postId)
    try {
      const { postId, restaurantId } = feedbackModal
      await updateDoc(doc(db, 'foodPosts', postId), {
        status: 'collected',
      })
      if (restaurantId) {
        const { addDoc } = await import('firebase/firestore')
        await addDoc(collection(db, 'restaurantFeedbacks'), {
          restaurantId,
          postId,
          ngoId: auth.currentUser?.uid,
          rating,
          comment: feedbackText,
          createdAt: new Date(),
        })
      }
      setPosts((prev) => prev.map((p) => (p.id === postId ? { ...p, status: 'collected' } : p)))
      toast.success('Marked as collected & feedback submitted!')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to mark as collected')
    } finally {
      setUpdatingId(null)
      setFeedbackModal(null)
    }
  }

  const stats = useMemo(() => {
    const totalAccepted = posts.length
    const mealsSaved = posts.reduce((sum, p) => sum + parseMeals(p.quantity), 0)
    const collected = posts.filter((p) => p.status === 'collected').length
    const pending = posts.filter((p) => p.status !== 'collected').length
    return { totalAccepted, mealsSaved, collected, pending }
  }, [posts])

  const statCards = [
    { label: 'Total Accepted', value: stats.totalAccepted, icon: '🍽️', color: 'text-purple-400' },
    { label: 'Meals Saved',    value: stats.mealsSaved,   icon: '👥', color: 'text-blue-400'   },
    { label: 'Collected',      value: stats.collected,    icon: '✅', color: 'text-emerald-400' },
    { label: 'Pending',        value: stats.pending,      icon: '⏳', color: 'text-amber-400'   },
  ]

  return (
    <NGOSidebarLayout title="My Activity">
      <div className="mx-auto w-full max-w-7xl space-y-6">
        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          {statCards.map((s) => (
            <div key={s.label} className="glass-stats-card p-5">
              <div className="text-2xl mb-1">{s.icon}</div>
              <div className="text-xs font-semibold uppercase tracking-wide text-white/35">{s.label}</div>
              <div className={`mt-1.5 text-3xl font-bold ${s.color}`}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Accepted Food List */}
        <section className="card-surface overflow-hidden">
          <div className="border-b border-white/06 px-6 py-4">
            <h2 className="text-base font-semibold text-white/80">Accepted Food</h2>
          </div>

          <div className="p-4">
            {loading ? (
              <div className="flex items-center gap-3 py-2">
                <Spinner size="sm" />
                <span className="text-sm text-white/50">Loading activity...</span>
              </div>
            ) : posts.length === 0 ? (
              <p className="text-sm text-white/35 py-4 text-center">No accepted posts yet.</p>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {posts.map((post) => {
                  const isCollected = post.status === 'collected'
                  const acceptedText =
                    post.acceptedAt ||
                    (post.claimedAt?.seconds
                      ? new Date(post.claimedAt.seconds * 1000).toLocaleString()
                      : 'N/A')
                  return (
                    <article
                      key={post.id}
                      className="rounded-2xl p-4"
                      style={{
                        border: '1px solid rgba(255,255,255,0.06)',
                        background: 'rgba(255,255,255,0.025)',
                        transition: 'all 0.2s ease',
                      }}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-white/90 truncate">
                            {post.foodName} · {post.quantity}
                          </div>
                          <div className="mt-1 text-sm text-white/45 truncate">{post.pickupAddress}</div>
                          <div className="mt-1 text-xs text-white/30">Accepted: {acceptedText}</div>
                        </div>
                        <span className={isCollected ? 'badge badge-green shrink-0' : 'badge badge-amber shrink-0'}>
                          {isCollected ? 'Collected' : 'Pending Pickup'}
                        </span>
                      </div>
                      {!isCollected && (
                        <button
                          type="button"
                          onClick={() => openFeedbackModal(post.id, post.restaurantId)}
                          disabled={updatingId === post.id}
                          className="cta-btn mt-3 w-full py-2.5 text-sm disabled:opacity-50"
                          style={{
                            background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
                            boxShadow: '0 4px 16px rgba(5,150,105,0.28)',
                          }}
                        >
                          {updatingId === post.id ? 'Updating...' : '✓ Mark as Collected'}
                        </button>
                      )}
                    </article>
                  )
                })}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Feedback Modal */}
      {feedbackModal?.isOpen && (
        <div className="glass-overlay">
          <div
            className="w-full max-w-md animate-fade-up"
            style={{
              borderRadius: 20,
              border: '1px solid rgba(255,255,255,0.09)',
              background: 'rgba(12,12,20,0.95)',
              boxShadow: '0 24px 48px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.07)',
              backdropFilter: 'blur(24px)',
              WebkitBackdropFilter: 'blur(24px)',
              padding: 28,
            }}
          >
            <h3 className="text-xl font-bold text-white mb-1">Collection Feedback</h3>
            <p className="text-sm text-white/45 mb-5">
              Please rate the restaurant and leave an optional comment.
            </p>

            {/* Star Rating */}
            <div className="flex items-center gap-2 mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  className={`text-3xl transition-all duration-150 hover:scale-110 ${
                    rating >= star ? 'text-yellow-400' : 'text-white/20'
                  }`}
                >
                  ★
                </button>
              ))}
            </div>

            <textarea
              className="glass-input resize-none"
              rows={3}
              placeholder="Any additional feedback? (Optional)"
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
            />

            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                className="soft-btn px-4 py-2.5 text-sm"
                onClick={() => setFeedbackModal(null)}
              >
                Cancel
              </button>
              <button
                type="button"
                className="cta-btn px-4 py-2.5 text-sm disabled:opacity-50"
                style={{
                  background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
                  boxShadow: '0 4px 16px rgba(5,150,105,0.28)',
                }}
                onClick={markCollected}
                disabled={!!updatingId}
              >
                {updatingId ? 'Submitting...' : 'Submit Collection'}
              </button>
            </div>
          </div>
        </div>
      )}
    </NGOSidebarLayout>
  )
}
