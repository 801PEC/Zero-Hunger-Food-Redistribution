import { onAuthStateChanged } from 'firebase/auth'
import { collection, getDocs, query, orderBy } from 'firebase/firestore'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { FaSearch, FaFilter, FaDownload } from 'react-icons/fa'
import { AdminTopNavbarLayout } from '../components/admin/AdminTopNavbarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type FoodPost = {
  id: string
  foodName?: string
  quantity?: string
  pickupAddress?: string
  expiryTime?: string
  status?: 'available' | 'claimed' | 'collected'
  restaurantId?: string
  createdAt?: any
}

export function AdminPostsPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [posts, setPosts] = useState<FoodPost[]>([])
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState<'all' | 'available' | 'claimed' | 'collected'>('all')

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        navigate('/')
        return
      }
      try {
        setLoading(true)
        const q = query(collection(db, 'foodPosts'), orderBy('createdAt', 'desc'))
        const snap = await getDocs(q)
        setPosts(snap.docs.map((d) => ({ id: d.id, ...(d.data() as Omit<FoodPost, 'id'>) })))
      } catch (err) {
        toast.error('Failed to load global posts feed')
      } finally {
        setLoading(false)
      }
    })
    return () => unsub()
  }, [navigate])

  const filteredPosts = posts.filter(p => {
    const matchesSearch = (p.foodName || '').toLowerCase().includes(search.toLowerCase()) || 
                         (p.pickupAddress || '').toLowerCase().includes(search.toLowerCase())
    const matchesFilter = filterStatus === 'all' || p.status === filterStatus
    return matchesSearch && matchesFilter
  })

  return (
    <AdminTopNavbarLayout title="Global Inventory">
      <div className="mx-auto w-full max-w-7xl space-y-6 pb-10">
        
        {/* Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="relative flex-1 min-w-[300px]">
             <FaSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" />
             <input 
               type="text"
               placeholder="Search by food name or address..."
               value={search}
               onChange={(e) => setSearch(e.target.value)}
               className="glass-input pl-11"
             />
          </div>
          <div className="flex items-center gap-3">
             <div className="flex items-center gap-2 rounded-xl bg-white/05 p-1 border border-white/08">
                {(['all', 'available', 'claimed', 'collected'] as const).map(s => (
                  <button
                    key={s}
                    onClick={() => setFilterStatus(s)}
                    className={`px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider rounded-lg transition-all ${
                      filterStatus === s ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30' : 'text-white/30 hover:text-white/60'
                    }`}
                  >
                    {s}
                  </button>
                ))}
             </div>
             <button className="soft-btn px-4 py-2.5">
                <FaDownload className="mr-2" /> Export CSV
             </button>
          </div>
        </div>

        {loading ? (
          <div className="card-surface p-12 text-center">
            <Spinner />
            <p className="mt-4 text-sm text-white/30 tracking-widest uppercase font-bold">Querying Infrastructure...</p>
          </div>
        ) : (
          <section className="card-surface overflow-hidden">
            <div className="overflow-x-auto">
              <table className="glass-table w-full text-left">
                <thead>
                  <tr>
                    <th>Post ID</th>
                    <th>Food Item</th>
                    <th>Quantity</th>
                    <th>Location Details</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredPosts.map((post) => (
                    <tr key={post.id} className="group">
                      <td className="font-mono text-[10px] text-white/20 group-hover:text-purple-400 transition-colors">#{post.id.slice(0, 8)}</td>
                      <td>
                         <div className="font-bold text-white/90">{post.foodName || '—'}</div>
                         <div className="text-[10px] text-white/30 uppercase tracking-tighter">Listed {timeAgo(post.createdAt)}</div>
                      </td>
                      <td className="text-sm font-medium">{post.quantity || '—'}</td>
                      <td className="max-w-xs">
                        <div className="truncate text-xs text-white/60">{post.pickupAddress || '—'}</div>
                      </td>
                      <td>
                        <span className={`badge ${
                          post.status === 'claimed' ? 'badge-amber' : post.status === 'collected' ? 'badge-purple' : 'badge-green'
                        }`}>
                          {post.status || 'available'}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {filteredPosts.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-20 text-center">
                         <FaFilter className="mx-auto mb-4 text-white/10" size={32} />
                         <p className="text-white/30 font-medium">No posts match your filters</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </div>
    </AdminTopNavbarLayout>
  )
}

function timeAgo(dateOrString: any) {
  if (!dateOrString) return 'Just now'
  let date: Date
  if (dateOrString instanceof Date) date = dateOrString
  else if (dateOrString?.toDate) date = dateOrString.toDate()
  else date = new Date(dateOrString)

  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
  if (seconds < 60) return `${Math.max(0, seconds)}s ago`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  return `${days}d ago`
}
