import { onAuthStateChanged } from 'firebase/auth'
import { doc, setDoc } from 'firebase/firestore'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { auth, db } from '../lib/firebase'
import { type SignupRole, getDashboardPathByRole } from '../lib/rbac'

export function SelectRolePage() {
  const navigate = useNavigate()
  const [uid, setUid] = useState<string | null>(null)
  const [email, setEmail] = useState<string | null>(null)
  const [savingRole, setSavingRole] = useState<SignupRole | null>(null)

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user: any) => {
      if (!user) {
        navigate('/login', { replace: true })
        return
      }
      setUid(user.uid)
      setEmail(user.email || null)
    })
    return () => unsub()
  }, [navigate])

  async function saveRole(role: SignupRole) {
    if (!uid) return
    setSavingRole(role)
    try {
      await setDoc(
        doc(db, 'users', uid),
        {
          uid,
          email,
          role,
          updatedAt: new Date().toISOString(),
        },
        { merge: true },
      )
      toast.success('Role saved successfully')
      navigate(getDashboardPathByRole(role), { replace: true })
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save role')
    } finally {
      setSavingRole(null)
    }
  }

  return (
    <div className="glass-page min-h-screen flex items-center justify-center px-4 py-20">
      <main className="w-full max-w-2xl text-center animate-fade-up">
        <div className="mb-2 inline-flex items-center gap-2 rounded-full border border-purple-500/20 bg-purple-500/10 px-3 py-1 text-xs font-medium text-purple-300">
          <span className="pulse-dot" />
          One-time setup
        </div>
        <h1 className="mt-4 text-3xl font-bold text-white">Select Your Role</h1>
        <p className="mt-2 text-white/45">
          Your account is missing role info. Choose one role to continue.
        </p>

        <div className="mt-10 grid w-full gap-4 sm:grid-cols-2">
          {/* Restaurant card */}
          <button
            type="button"
            disabled={savingRole !== null}
            onClick={() => void saveRole('restaurant')}
            className="glass-card p-8 text-left group cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
            style={{ borderRadius: 18 }}
          >
            <div className="mb-3 text-3xl">🍽️</div>
            <div className="text-lg font-bold text-white group-hover:text-purple-200 transition-colors">
              {savingRole === 'restaurant' ? 'Setting up...' : "I'm a Restaurant"}
            </div>
            <div className="mt-1.5 text-sm text-white/45 leading-relaxed">
              Post surplus food for nearby NGOs to rescue and redistribute.
            </div>
            <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-purple-400 group-hover:text-purple-300 transition-colors">
              Select →
            </div>
          </button>

          {/* NGO card */}
          <button
            type="button"
            disabled={savingRole !== null}
            onClick={() => void saveRole('ngo')}
            className="glass-card p-8 text-left group cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
            style={{ borderRadius: 18 }}
          >
            <div className="mb-3 text-3xl">🤝</div>
            <div className="text-lg font-bold text-white group-hover:text-blue-200 transition-colors">
              {savingRole === 'ngo' ? 'Setting up...' : "I'm an NGO"}
            </div>
            <div className="mt-1.5 text-sm text-white/45 leading-relaxed">
              Discover and claim available food posts via smart AI matching.
            </div>
            <div className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-blue-400 group-hover:text-blue-300 transition-colors">
              Select →
            </div>
          </button>
        </div>
      </main>
    </div>
  )
}
