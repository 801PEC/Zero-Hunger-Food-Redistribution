// RestaurantProfilePage.tsx reformatted and polished
import { onAuthStateChanged } from 'firebase/auth'
import { collection, doc, getDoc, getDocs, query, setDoc, where } from 'firebase/firestore'
import { useEffect, useMemo, useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { RestaurantSidebarLayout } from '../components/restaurant/RestaurantSidebarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type UserProfile = {
  email?: string
  name?: string
  phone?: string
  address?: string
  description?: string
  photoDataUrl?: string
}

type Post = { quantity: string; status?: string }

type ProfileForm = {
  name: string
  email: string
  phone: string
  address: string
  description: string
  photoDataUrl: string
}

function parseMeals(quantity: string) {
  const match = quantity?.match(/(\d+(\.\d+)?)/)
  if (!match) return 0
  const n = Number(match[1])
  return Number.isNaN(n) ? 0 : n
}

/* ── Field Display Component ─────────────────────────────── */
function ProfileField({ label, value, fullWidth = false }: { label: string; value: string; fullWidth?: boolean }) {
  return (
    <div className={fullWidth ? 'sm:col-span-2' : ''}>
      <div className="text-[10px] font-bold uppercase tracking-widest text-white/25 mb-1">{label}</div>
      <div className="text-sm font-medium text-white/90 bg-white/03 border border-white/05 rounded-xl px-4 py-3 min-h-[44px] flex items-center">
        {value}
      </div>
    </div>
  )
}

export function RestaurantProfilePage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [uid, setUid] = useState<string>('')
  const [form, setForm] = useState<ProfileForm>({
    name: '',
    email: '',
    phone: '',
    address: '',
    description: '',
    photoDataUrl: '',
  })
  const [posts, setPosts] = useState<Post[]>([])

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        navigate('/login')
        return
      }
      setUid(user.uid)
      setLoading(true)
      try {
        const userSnap = await getDoc(doc(db, 'users', user.uid))
        const d = userSnap.data() as UserProfile | undefined
        const loadedProfile = d ?? { email: user.email ?? '' }
        
        const email = loadedProfile.email || user.email || ''
        setProfile({ ...loadedProfile, email })
        setForm({
          name: loadedProfile.name || '',
          email,
          phone: loadedProfile.phone || '',
          address: loadedProfile.address || '',
          description: loadedProfile.description || '',
          photoDataUrl: loadedProfile.photoDataUrl || '',
        })
        const postsSnap = await getDocs(query(collection(db, 'foodPosts'), where('restaurantId', '==', user.uid)))
        setPosts(postsSnap.docs.map((ds) => ds.data() as Post))
      } catch (err) {
        toast.error(err instanceof Error ? err.message : 'Failed to load profile')
      } finally {
        setLoading(false)
      }
    })
    return () => unsub()
  }, [navigate])

  const stats = useMemo(() => {
    const totalPosts = posts.length
    const totalMeals = posts.reduce((sum, p) => sum + parseMeals(p.quantity), 0)
    const claimedPosts = posts.filter((p) => p.status === 'claimed' || p.status === 'collected').length
    return { totalPosts, totalMeals, claimedPosts }
  }, [posts])

  function onFieldChange(field: keyof ProfileForm, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  async function onPhotoChange(file: File | null) {
    if (!file) return
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image too large (max 2MB)')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : ''
      setForm((prev) => ({ ...prev, photoDataUrl: result }))
    }
    reader.readAsDataURL(file)
  }

  function onCancelEdit() {
    if (!profile) return
    setForm({
      name: profile.name || '',
      email: profile.email || '',
      phone: profile.phone || '',
      address: profile.address || '',
      description: profile.description || '',
      photoDataUrl: profile.photoDataUrl || '',
    })
    setIsEditing(false)
  }

  async function onSaveProfile() {
    if (!uid) return
    if (!form.name.trim()) return toast.error('Restaurant name is required')
    
    setSaving(true)
    try {
      const payload = {
        uid,
        role: 'restaurant',
        name: form.name.trim(),
        email: form.email,
        phone: form.phone.trim(),
        address: form.address.trim(),
        description: form.description.trim(),
        photoDataUrl: form.photoDataUrl || '',
        updatedAt: new Date().toISOString(),
      }
      
      await setDoc(doc(db, 'users', uid), payload, { merge: true })
      setProfile(payload)
      setIsEditing(false)
      toast.success('Profile saved!')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to direct save')
    } finally {
      setSaving(false)
    }
  }

  return (
    <RestaurantSidebarLayout title="Profile">
      <div className="mx-auto w-full max-w-5xl space-y-6">

        {loading ? (
          <div className="flex items-center gap-3 p-8 card-surface">
            <Spinner size="sm" />
            <span className="text-sm text-white/40">Fetching profile data...</span>
          </div>
        ) : isEditing ? (
          /* ── Edit State ──────────────────────────────── */
          <section className="card-surface p-6 md:p-8 animate-fade-in">
            <div className="flex items-center justify-between mb-8 border-b border-white/05 pb-6">
               <h2 className="text-xl font-bold text-white">Edit Restaurant Profile</h2>
               <div className="text-[10px] font-bold uppercase tracking-widest text-white/20 italic">Partner Settings</div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <label className="block">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Restaurant Name</div>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => onFieldChange('name', e.target.value)}
                  className="glass-input"
                  placeholder="e.g. Central Kitchen"
                />
              </label>
              <label className="block">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Email (Read Only)</div>
                <input
                  type="text"
                  value={form.email}
                  readOnly
                  className="glass-input opacity-40 cursor-not-allowed"
                />
              </label>
              <label className="block">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Phone Number</div>
                <input
                  type="text"
                  value={form.phone}
                  onChange={(e) => onFieldChange('phone', e.target.value)}
                  className="glass-input"
                  placeholder="+1 (555) 000-0000"
                />
              </label>
              <label className="block md:col-span-1">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Location Address</div>
                <input
                  type="text"
                  value={form.address}
                  onChange={(e) => onFieldChange('address', e.target.value)}
                  className="glass-input"
                  placeholder="Street name, City, State"
                />
              </label>
              <label className="block md:col-span-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">About our Restaurant</div>
                <textarea
                  value={form.description}
                  onChange={(e) => onFieldChange('description', e.target.value)}
                  className="glass-input min-h-[100px] resize-none"
                  placeholder="Tell us about your cuisine or mission..."
                />
              </label>

              <div className="md:col-span-2 border-t border-white/05 pt-6 mt-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-4 ml-1">Profile Visuals</div>
                <div className="flex items-center gap-6">
                   <div className="relative group">
                     {form.photoDataUrl ? (
                         <img src={form.photoDataUrl} className="h-20 w-20 rounded-2xl object-cover ring-2 ring-amber-500/30" />
                     ) : (
                         <div className="h-20 w-20 rounded-2xl bg-white/05 border border-dashed border-white/10 grid place-items-center text-2xl">📸</div>
                     )}
                     {form.photoDataUrl && (
                        <button 
                           onClick={() => setForm(p => ({...p, photoDataUrl: ''}))}
                           className="absolute -top-2 -right-2 bg-red-500 h-6 w-6 rounded-full text-[10px] grid place-items-center shadow-lg transform group-hover:scale-110 transition-transform">✕</button>
                     )}
                   </div>
                   <label className="flex-1 cursor-pointer group">
                      <div className="glass-input flex items-center justify-center gap-2 text-sm text-white/40 group-hover:text-white/60 group-hover:bg-white/08 transition-all">
                        <span className="text-lg">📁</span>
                        {form.photoDataUrl ? 'Change Photo' : 'Upload Restaurant Logo'}
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => void onPhotoChange(e.target.files?.[0] ?? null)} />
                      </div>
                   </label>
                </div>
              </div>
            </div>

            <div className="mt-10 flex items-center gap-4">
              <button
                onClick={() => void onSaveProfile()}
                disabled={saving}
                className="cta-btn px-8 py-3 font-bold text-sm min-w-[140px] !from-amber-600 !to-amber-700 shadow-[0_4px_20px_rgba(217,119,6,0.25)]"
              >
                {saving ? 'Processing...' : 'Save Settings'}
              </button>
              <button
                onClick={onCancelEdit}
                className="soft-btn px-6 py-3 font-medium text-sm"
              >
                Discard
              </button>
            </div>
          </section>
        ) : (
          /* ── View State ──────────────────────────────── */
          <section className="animate-fade-in space-y-6">
            <div className="card-surface p-8 flex flex-col md:flex-row gap-8 items-start md:items-center relative overflow-hidden group">
               {/* Background Glow */}
               <div className="absolute -top-24 -right-24 h-64 w-64 bg-amber-600/10 blur-[100px] rounded-full pointer-events-none" />
               
               <div className="relative shrink-0">
                  {profile?.photoDataUrl ? (
                    <img src={profile.photoDataUrl} className="h-28 w-28 rounded-3xl object-cover ring-4 ring-white/05 shadow-2xl" />
                  ) : (
                    <div className="h-28 w-28 rounded-3xl bg-gradient-to-br from-amber-600/20 to-amber-800/20 ring-4 ring-white/05 shadow-2xl grid place-items-center text-4xl">🍽️</div>
                  )}
                  <div className="absolute -bottom-2 -right-2 h-8 w-8 rounded-xl bg-amber-500 grid place-items-center shadow-xl border-2 border-[#09090b]">
                    <span className="text-xs">★</span>
                  </div>
               </div>

               <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3">
                     <h2 className="text-3xl font-extrabold text-white tracking-tight">{profile?.name || 'Restaurant Partner'}</h2>
                     <span className="badge badge-amber px-3 py-1 text-[10px]">Gold Partner</span>
                  </div>
                  <p className="text-white/40 font-medium">{profile?.email}</p>
                  <p className="text-sm text-white/60 max-w-xl leading-relaxed italic border-l-2 border-amber-500/30 pl-4 py-1">
                    "{profile?.description || 'No description provided yet.'}"
                  </p>
               </div>

               <button
                 onClick={() => setIsEditing(true)}
                 className="md:self-start bg-white/05 hover:bg-white/10 text-white/70 hover:text-white px-5 py-2.5 rounded-2xl border border-white/10 transition-all font-semibold text-xs flex items-center gap-2"
               >
                 <span>⚙️</span> Edit Profile
               </button>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <ProfileField label="Contact Line" value={profile?.phone || 'Not provided'} />
              <ProfileField label="Food Pickup Location" value={profile?.address || 'Not set'} />
              <ProfileField label="Account Status" value="Active" />
            </div>

            <div className="grid gap-6 md:grid-cols-3 pt-4">
              <div className="glass-stats-card p-6 border-l-4 border-purple-500/50">
                  <div className="text-xs font-bold uppercase tracking-widest text-white/30 mb-1">Rescue Feed</div>
                  <div className="text-4xl font-black text-white">{stats.totalPosts}</div>
                  <div className="text-[10px] font-medium text-white/20 mt-2">Total food posts published</div>
              </div>
              <div className="glass-stats-card p-6 border-l-4 border-amber-500/50">
                  <div className="text-xs font-bold uppercase tracking-widest text-white/30 mb-1">Donation Impact</div>
                  <div className="text-4xl font-black text-white">{stats.totalMeals}</div>
                  <div className="text-[10px] font-medium text-white/20 mt-2">Estimated meals saved</div>
              </div>
              <div className="glass-stats-card p-6 border-l-4 border-emerald-500/50">
                  <div className="text-xs font-bold uppercase tracking-widest text-white/30 mb-1">Effective Waste Reduction</div>
                  <div className="text-4xl font-black text-white">{stats.claimedPosts}</div>
                  <div className="text-[10px] font-medium text-white/20 mt-2">Successful NGO pickups</div>
              </div>
            </div>
          </section>
        )}

      </div>
    </RestaurantSidebarLayout>
  )
}
