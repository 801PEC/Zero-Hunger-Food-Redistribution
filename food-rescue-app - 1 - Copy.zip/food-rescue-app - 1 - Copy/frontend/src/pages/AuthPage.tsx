import type { ChangeEvent, FormEvent } from 'react'
import { useEffect, useState } from 'react'
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth'
import { signOut } from 'firebase/auth'
import { doc, setDoc } from 'firebase/firestore'
import toast from 'react-hot-toast'
import { FiMoon, FiSun } from 'react-icons/fi'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { auth, db } from '../lib/firebase'
import { type SignupRole, getDashboardPathByRole, getUserRole } from '../lib/rbac'
import { useTheme } from '../lib/theme'

type Mode = 'login' | 'signup'

export function AuthPage() {
  const navigate = useNavigate()
  const { theme, toggleTheme } = useTheme()
  const [params] = useSearchParams()
  const [role, setRole] = useState<SignupRole>('restaurant')
  const [mode, setMode] = useState<Mode>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    const qRole = params.get('role')
    if (qRole === 'restaurant' || qRole === 'ngo') {
      setRole(qRole)
    }
  }, [params])

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setBusy(true)
    try {
      if (mode === 'login') {
        const cred = await signInWithEmailAndPassword(auth, email, password)
        const savedRole = await getUserRole(cred.user.uid)
        // eslint-disable-next-line no-console
        console.log('[Auth] role fetched from Firestore (login):', savedRole)
        if (!savedRole) {
          toast('Please select your role to continue.')
          navigate('/select-role')
          return
        }

        const requestedRole = params.get('role')
        if (
          (requestedRole === 'restaurant' || requestedRole === 'ngo') &&
          savedRole !== requestedRole
        ) {
          await signOut(auth)
          const savedRoleLabel = savedRole === 'ngo' ? 'NGO' : savedRole === 'restaurant' ? 'Restaurant' : 'Admin'
          toast.error(`This account is registered as a ${savedRoleLabel}`)
          return
        }

        navigate(getDashboardPathByRole(savedRole))
        toast.success('Logged in successfully')
      } else {
        const cred = await createUserWithEmailAndPassword(auth, email, password)
        // eslint-disable-next-line no-console
        console.log('[Auth] saving signup role to Firestore:', role)
        await setDoc(
          doc(db, 'users', cred.user.uid),
          {
            uid: cred.user.uid,
            email: cred.user.email,
            role,
            createdAt: new Date().toISOString(),
          },
          { merge: false },
        )
        // eslint-disable-next-line no-console
        console.log('[Auth] saved role to Firestore:', role)
        navigate(getDashboardPathByRole(role))
        toast.success('Account created successfully')
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Authentication failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="glass-page min-h-screen flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-md animate-fade-up">
        {/* Card */}
        <div
          style={{
            borderRadius: 20,
            border: '1px solid rgba(255,255,255,0.08)',
            background: 'rgba(255,255,255,0.04)',
            boxShadow: '0 24px 48px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.07)',
            backdropFilter: 'blur(24px)',
            WebkitBackdropFilter: 'blur(24px)',
            padding: '32px',
          }}
        >
          {/* Theme toggle */}
          <div className="mb-4 flex justify-end">
            <button
              type="button"
              onClick={toggleTheme}
              className="rounded-lg border border-white/08 bg-white/04 p-2 text-white/50 hover:text-white hover:bg-white/10 transition-all"
            >
              {theme === 'dark' ? <FiSun className="h-4 w-4" /> : <FiMoon className="h-4 w-4" />}
            </button>
          </div>

          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-white">Welcome to Zero Hunger</h1>
            <p className="mt-1 text-sm text-white/45">Login or create an account to continue.</p>
          </div>

          {/* Mode tabs */}
          <div className="glass-tabs mb-4">
            <button
              type="button"
              onClick={() => setMode('login')}
              className={`glass-tab${mode === 'login' ? ' active' : ''}`}
            >
              Login
            </button>
            <button
              type="button"
              onClick={() => setMode('signup')}
              className={`glass-tab${mode === 'signup' ? ' active' : ''}`}
            >
              Sign up
            </button>
          </div>

          {/* Role tabs */}
          <div className="glass-tabs mb-6">
            {(['restaurant', 'ngo'] as SignupRole[]).map((r) => (
              <button
                key={r}
                type="button"
                onClick={() => setRole(r)}
                className={`glass-tab capitalize${role === r ? ' active' : ''}`}
              >
                {r === 'ngo' ? 'NGO' : 'Restaurant'}
              </button>
            ))}
          </div>

          {/* Form */}
          <form onSubmit={onSubmit} className="space-y-4">
            <input
              type="email"
              required
              value={email}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setEmail(e.target.value)}
              className="glass-input"
              placeholder="Email address"
            />
            <input
              type="password"
              required
              value={password}
              onChange={(e: ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
              className="glass-input"
              placeholder="Password"
            />

            <button
              type="submit"
              disabled={busy}
              className="cta-btn w-full py-3 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ borderRadius: 12 }}
            >
              {busy ? 'Please wait...' : mode === 'login' ? 'Login' : 'Create account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}
