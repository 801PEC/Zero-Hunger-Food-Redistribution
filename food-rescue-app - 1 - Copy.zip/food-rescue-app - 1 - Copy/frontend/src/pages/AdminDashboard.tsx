import { useEffect, useState, useMemo } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import { collection, getDocs } from 'firebase/firestore'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet'
import 'leaflet/dist/leaflet.css'
import { FaUtensils, FaMapMarkerAlt, FaCheckCircle, FaExclamationTriangle, FaClock, FaChartBar, FaUserShield } from 'react-icons/fa'

import { AdminTopNavbarLayout } from '../components/admin/AdminTopNavbarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type UserProfile = {
  id: string
  role?: string
  name?: string
  ngoName?: string
  email?: string
}

type FoodPost = {
  id: string
  foodName?: string
  quantity?: string
  pickupAddress?: string
  expiryTime?: string
  createdAt?: any
  status?: 'available' | 'claimed' | 'collected'
  riskLevel?: string
  restaurantId?: string
  acceptedBy?: string
  claimedBy?: string 
  latitude?: number
  longitude?: number
}

function parseMeals(q: string | undefined): number {
  if (!q) return 1
  const match = q.match(/(\d+(\.\d+)?)/)
  if (!match) return 1
  const n = Number(match[1])
  return Number.isNaN(n) ? 1 : n
}

function timeAgo(dateOrString: any) {
  if (!dateOrString) return 'Just now'
  let date: Date
  if (dateOrString instanceof Date) date = dateOrString
  else if (dateOrString?.toDate) date = dateOrString.toDate()
  else date = new Date(dateOrString)

  const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)
  if (seconds < 60) return `${Math.max(0, seconds)}s ago`
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes}m ago`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  return `${days}d ago`
}

function AnimatedNumber({ value }: { value: number }) {
  const [display, setDisplay] = useState(0)
  
  useEffect(() => {
    let start = 0
    const duration = 1000
    const increment = Math.ceil(value / 50) || 1
    
    if (value === 0) {
      setDisplay(0)
      return
    }
    
    const timer = setInterval(() => {
      start += increment
      if (start >= value) {
        setDisplay(value)
        clearInterval(timer)
      } else {
        setDisplay(start)
      }
    }, 20)
    
    return () => clearInterval(timer)
  }, [value])
  
  return <>{display.toLocaleString()}</>
}

export function AdminDashboard() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [posts, setPosts] = useState<FoodPost[]>([])
  const [users, setUsers] = useState<Record<string, UserProfile>>({})
  const [error, setError] = useState<string | null>(null)

  const fetchData = async () => {
    try {
      const [postSnap, userSnap] = await Promise.all([
        getDocs(collection(db, 'foodPosts')),
        getDocs(collection(db, 'users'))
      ])
      
      const items = postSnap.docs.map((d) => ({ id: d.id, ...d.data() }) as FoodPost)
      const userMap: Record<string, UserProfile> = {}
      userSnap.docs.forEach((d) => {
        userMap[d.id] = { id: d.id, ...d.data() } as UserProfile
      })
      
      setPosts(items)
      setUsers(userMap)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Database fetch failed')
    }
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        navigate('/')
        return
      }
      setLoading(true)
      await fetchData()
      setLoading(false)
      
      const interval = setInterval(() => {
        void fetchData()
      }, 30000)
      
      return () => clearInterval(interval)
    })
    return () => unsub()
  }, [navigate])

  // Calculated Stats
  const stats = useMemo(() => {
    const totalMeals = posts.reduce((sum, p) => sum + parseMeals(p.quantity), 0)
    const claimed = posts.filter(p => p.status === 'claimed').length
    const collected = posts.filter(p => p.status === 'collected').length
    const critical = posts.filter(p => p.riskLevel === 'CRITICAL' || p.status === 'expired').length
    
    // Today's Meals
    const today = new Date()
    const todayMeals = posts.filter(p => {
       const d = p.createdAt?.toDate ? p.createdAt.toDate() : new Date(p.createdAt || 0)
       return d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear()
    }).reduce((sum, p) => sum + parseMeals(p.quantity), 0)

    return { totalPosts: posts.length, totalMeals, claimed, collected, critical, todayMeals }
  }, [posts])

  const liveFeed = useMemo(() => {
    return [...posts].sort((a, b) => {
      const db = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : new Date(b.createdAt || 0).getTime()
      const da = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : new Date(a.createdAt || 0).getTime()
      return db - da
    }).slice(0, 8)
  }, [posts])

  const categoryStats = useMemo(() => {
    const counts: Record<string, number> = {}
    posts.forEach(p => {
       if (p.foodName) {
          const cat = p.foodName.toLowerCase().split(' ')[0]
          counts[cat] = (counts[cat] || 0) + 1
       }
    })
    return Object.entries(counts)
      .map(([name, count]) => ({ name: name.charAt(0).toUpperCase() + name.slice(1), count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 5)
  }, [posts])
  const maxCatCount = categoryStats.length ? categoryStats[0].count : 1

  const rankings = useMemo(() => {
    const rStats: Record<string, { posts: number, meals: number }> = {}
    const nStats: Record<string, { collections: number, meals: number }> = {}

    posts.forEach(p => {
       if (p.restaurantId) {
         if (!rStats[p.restaurantId]) rStats[p.restaurantId] = { posts: 0, meals: 0 }
         rStats[p.restaurantId].posts += 1
         rStats[p.restaurantId].meals += parseMeals(p.quantity)
       }
       
       const ngoId = p.acceptedBy || p.claimedBy
       if (ngoId && p.status === 'collected') {
         if (!nStats[ngoId]) nStats[ngoId] = { collections: 0, meals: 0 }
         nStats[ngoId].collections += 1
         nStats[ngoId].meals += parseMeals(p.quantity)
       }
    })

    const topRestaurants = Object.entries(rStats)
       .sort((a, b) => b[1].posts - a[1].posts)
       .slice(0, 5)
       .map(([id, st]) => ({ id, name: users[id]?.name || 'Unknown Restaurant', ...st }))

    const topNgos = Object.entries(nStats)
       .sort((a, b) => b[1].collections - a[1].collections)
       .slice(0, 5)
       .map(([id, st]) => ({ id, name: users[id]?.ngoName || users[id]?.name || 'Unknown NGO', ...st }))

    return { topRestaurants, topNgos }
  }, [posts, users])

  if (loading) {
    return (
      <AdminTopNavbarLayout title="Admin Overview">
        <div className="flex h-64 items-center justify-center gap-3">
          <Spinner />
          <span className="text-sm text-white/40">Syncing live dashboard...</span>
        </div>
      </AdminTopNavbarLayout>
    )
  }

  return (
    <AdminTopNavbarLayout title="Dashboard">
      <div className="mx-auto w-full max-w-7xl space-y-8 pb-10">
        
        {/* IMPACT HERO SECTION */}
        <motion.section 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="card-surface relative overflow-hidden p-10 text-center dark-hero-glow"
        >
          <div className="absolute left-6 top-6 flex items-center gap-2">
            <span className="pulse-dot" />
            <span className="text-[10px] font-bold tracking-[0.2em] text-emerald-400">LIVE FEED</span>
          </div>
          <h2 className="glow-text text-5xl font-black sm:text-7xl">
            <AnimatedNumber value={stats.todayMeals} />
          </h2>
          <p className="mt-3 text-lg font-medium text-white/40">Meals Redispersed Successfully Today</p>
          <div className="mt-6 flex justify-center gap-10">
             <div className="text-center">
                <div className="text-2xl font-bold text-white/90"><AnimatedNumber value={stats.totalMeals} /></div>
                <p className="text-[10px] font-semibold uppercase tracking-widest text-white/25">Total Lifetime Meals</p>
             </div>
             <div className="text-center">
                <div className="text-2xl font-bold text-purple-400"><AnimatedNumber value={Object.keys(users).length} /></div>
                <p className="text-[10px] font-semibold uppercase tracking-widest text-white/25">Registered Users</p>
             </div>
          </div>
        </motion.section>

        {/* STATUS CARDS */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="glass-stats-card p-5 border-t-2 border-emerald-500/30">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-white/30">Available Posts</span>
              <FaUtensils className="text-emerald-400" />
            </div>
            <div className="mt-3 text-3xl font-bold"><AnimatedNumber value={posts.filter(p => !p.status || p.status === 'available').length} /></div>
          </div>
          <div className="glass-stats-card p-5 border-t-2 border-amber-500/30">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-white/30">Pending Claimed</span>
              <FaClock className="text-amber-400" />
            </div>
            <div className="mt-3 text-3xl font-bold"><AnimatedNumber value={stats.claimed} /></div>
          </div>
          <div className="glass-stats-card p-5 border-t-2 border-blue-500/30">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-white/30">Total Pickups</span>
              <FaCheckCircle className="text-blue-400" />
            </div>
            <div className="mt-3 text-3xl font-bold"><AnimatedNumber value={stats.collected} /></div>
          </div>
          <div className="glass-stats-card p-5 border-t-2 border-red-500/30">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-white/30">Critical Waste</span>
              <FaExclamationTriangle className="text-red-400" />
            </div>
            <div className="mt-3 text-3xl font-bold"><AnimatedNumber value={stats.critical} /></div>
          </div>
        </div>

        {error && <div className="alert-error">{error}</div>}

        {/* ANALYTICS GRID */}
        <div className="grid gap-6 lg:grid-cols-3">
          
          {/* Live Table Feed */}
          <div className="card-surface col-span-1 flex flex-col p-6 lg:col-span-2">
            <div className="mb-6 flex items-center justify-between">
              <h3 className="flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-white/60">
                <span className="h-4 w-1 rounded-full bg-purple-500" />
                Global Activity Feed
              </h3>
              <button onClick={fetchData} className="text-white/30 hover:text-white"><FaClock size={14} /></button>
            </div>
            <div className="flex-1 overflow-x-auto">
              <table className="glass-table w-full text-left">
                <thead>
                  <tr>
                    <th>Entry</th>
                    <th>Source</th>
                    <th>Status</th>
                    <th>Time</th>
                  </tr>
                </thead>
                <tbody>
                  {liveFeed.map((post) => (
                    <tr key={post.id}>
                      <td className="font-semibold text-white/90">{post.foodName || 'Unspecified'} <span className="text-[10px] text-white/40 ml-1">({post.quantity})</span></td>
                      <td className="text-xs">{users[post.restaurantId || '']?.name || '—'}</td>
                      <td>
                        <span className={`badge ${
                          post.status === 'claimed' ? 'badge-amber' : post.status === 'collected' ? 'badge-purple' : 'badge-green'
                        }`}>
                          {post.status || 'available'}
                        </span>
                      </td>
                      <td className="text-[10px] text-white/30">{timeAgo(post.createdAt)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Charts & Map */}
          <div className="space-y-6">
            <div className="card-surface p-6">
               <h3 className="mb-5 flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-white/60">
                 <FaChartBar className="text-purple-400" /> Popular Items
               </h3>
               <div className="space-y-4">
                  {categoryStats.map((cat, idx) => (
                    <div key={idx}>
                      <div className="mb-1 flex justify-between text-[10px] font-bold uppercase text-white/40">
                        <span>{cat.name}</span>
                        <span>{cat.count}</span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-white/05 overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${(cat.count / maxCatCount) * 100}%` }}
                          transition={{ duration: 1.5, ease: "easeOut" }}
                          className="h-full rounded-full bg-gradient-to-r from-purple-500 to-indigo-500"
                        />
                      </div>
                    </div>
                  ))}
               </div>
            </div>

            <div className="card-surface overflow-hidden p-0" style={{ height: 260 }}>
               <MapContainer center={[20.5, 78.5]} zoom={3} className="h-full w-full grayscale-[0.6] invert-[0.1]">
                  <TileLayer url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png" />
                  {posts.filter(p => p.latitude && p.longitude).map(p => (
                    <CircleMarker 
                      key={p.id} 
                      center={[p.latitude!, p.longitude!]} 
                      radius={6}
                      pathOptions={{ 
                        fillColor: p.status === 'collected' ? '#a78bfa' : p.status === 'claimed' ? '#fbbf24' : '#34d399', 
                        color: 'white', 
                        weight: 1, 
                        fillOpacity: 0.8 
                      }}
                    >
                      <Popup className="dark-popup">
                        <div className="text-xs font-bold">{p.foodName}</div>
                        <div className="text-[10px] opacity-70">{p.pickupAddress}</div>
                      </Popup>
                    </CircleMarker>
                  ))}
               </MapContainer>
            </div>
          </div>

        </div>

        {/* LEADERBOARDS */}
        <div className="grid gap-6 lg:grid-cols-2">
           <div className="card-surface p-6">
              <h3 className="mb-6 flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-white/60">
                <FaUserShield className="text-emerald-400" /> Top Provider Leaderboard
              </h3>
              <div className="space-y-3">
                 {rankings.topRestaurants.map((res, i) => (
                    <div key={res.id} className="flex items-center justify-between rounded-xl bg-white/05 p-3">
                       <div className="flex items-center gap-4">
                          <span className="text-xs font-black text-white/20">0{i+1}</span>
                          <div>
                             <p className="text-xs font-bold text-white/90">{res.name}</p>
                             <p className="text-[10px] text-white/30">{res.posts} Posts Published</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-sm font-black text-emerald-400">{res.meals}</p>
                          <p className="text-[9px] font-semibold uppercase tracking-tighter text-white/20">Meals Saved</p>
                       </div>
                    </div>
                 ))}
              </div>
           </div>

           <div className="card-surface p-6">
              <h3 className="mb-6 flex items-center gap-2 text-sm font-bold uppercase tracking-widest text-white/60">
                 <FaCheckCircle className="text-blue-400" /> Top Rescuer Leaderboard
              </h3>
              <div className="space-y-3">
                 {rankings.topNgos.map((ngo, i) => (
                    <div key={ngo.id} className="flex items-center justify-between rounded-xl bg-white/05 p-3">
                       <div className="flex items-center gap-4">
                          <span className="text-xs font-black text-white/20">0{i+1}</span>
                          <div>
                             <p className="text-xs font-bold text-white/90">{ngo.name}</p>
                             <p className="text-[10px] text-white/30">{ngo.collections} Pickups Completed</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-sm font-black text-blue-400">{ngo.meals}</p>
                          <p className="text-[9px] font-semibold uppercase tracking-tighter text-white/20">Meals Delivered</p>
                       </div>
                    </div>
                 ))}
              </div>
           </div>
        </div>

      </div>

      <style>{`
        .dark-popup .leaflet-popup-content-wrapper { background: #0f172a; color: white; border: 1px solid rgba(255,255,255,0.1); }
        .dark-popup .leaflet-popup-tip { background: #0f172a; }
      `}</style>
    </AdminTopNavbarLayout>
  )
}
