import type { ChangeEvent, FormEvent } from 'react'
import { useEffect, useState } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import {
  addDoc,
  collection,
  doc,
  updateDoc,
  serverTimestamp,
} from 'firebase/firestore'
import toast from 'react-hot-toast'
import { FaClock, FaMapMarkerAlt, FaUtensils } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'
import { RestaurantSidebarLayout } from '../components/restaurant/RestaurantSidebarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'
import {
  analyzeFoodImageWithGemini,
  type FoodQualityStatus,
  type GeminiFoodAnalysis,
} from '../lib/geminiFoodQuality'

type AddressSuggestion = { display_name: string; lat: string; lon: string }

async function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ''))
    reader.onerror = () => reject(new Error('Failed to read image file'))
    reader.readAsDataURL(file)
  })
}

async function geocodeAddress(address: string) {
  const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`
  const resp = await fetch(url, { headers: { Accept: 'application/json' } })
  if (!resp.ok) return null
  const data = (await resp.json()) as AddressSuggestion[]
  if (!data.length) return null
  const lat = Number(data[0].lat)
  const lon = Number(data[0].lon)
  if (Number.isNaN(lat) || Number.isNaN(lon)) return null
  return { lat, lon }
}

export function RestaurantDashboard() {
  const navigate = useNavigate()

  const [restaurantId, setRestaurantId] = useState<string | null>(null)
  const [loadingUser, setLoadingUser] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const [foodName, setFoodName] = useState('')
  const [quantity, setQuantity] = useState('')
  const [pickupAddress, setPickupAddress] = useState('')
  const [cookedTime, setCookedTime] = useState('')
  const [cookingTime, setCookingTime] = useState('')
  const [expiryTime, setExpiryTime] = useState('')
  const [photoFile, setPhotoFile] = useState<File | null>(null)

  const [photoPreviewUrl, setPhotoPreviewUrl] = useState<string | null>(null)
  const [analyzingPhoto, setAnalyzingPhoto] = useState(false)
  const [photoAnalysis, setPhotoAnalysis] = useState<GeminiFoodAnalysis | null>(null)

  const [addressSuggestions, setAddressSuggestions] = useState<AddressSuggestion[]>([])
  const [showAddressDropdown, setShowAddressDropdown] = useState(false)
  const [selectedCoords, setSelectedCoords] = useState<{ lat: number; lon: number } | null>(null)

  const [aiRiskResult, setAiRiskResult] = useState<any>(null)

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user: any) => {
      if (!user) {
        navigate('/')
        return
      }
      setRestaurantId(user.uid)
      setLoadingUser(false)
    })
    return () => unsub()
  }, [navigate])

  useEffect(() => {
    if (!photoFile) {
      setPhotoPreviewUrl(null)
      return
    }
    const url = URL.createObjectURL(photoFile)
    setPhotoPreviewUrl(url)
    return () => URL.revokeObjectURL(url)
  }, [photoFile])

  useEffect(() => {
    if (!foodName || !cookingTime) {
      setAiRiskResult(null)
      return
    }
    const timer = setTimeout(async () => {
      try {
        const predictRes = await fetch(`${import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'}/api/food-safety-score`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            foodName, 
            cookingTime, 
            quantity, 
            lat: selectedCoords?.lat, 
            lng: selectedCoords?.lon 
          }),
        })
        if (predictRes.ok) {
          const aiData = await predictRes.json()
          setAiRiskResult(aiData)
        }
      } catch (err) {
        // console.error(err)
      }
    }, 500)
    return () => clearTimeout(timer)
  }, [foodName, cookingTime, quantity, selectedCoords])


  useEffect(() => {
    const q = pickupAddress.trim()
    if (q.length < 3) {
      setAddressSuggestions([])
      return
    }

    const timer = setTimeout(async () => {
      try {
        const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=5`
        const resp = await fetch(url, { headers: { Accept: 'application/json' } })
        if (!resp.ok) return
        const data = (await resp.json()) as AddressSuggestion[]
        setAddressSuggestions(data)
      } catch {
        setAddressSuggestions([])
      }
    }, 300)

    return () => clearTimeout(timer)
  }, [pickupAddress])

  function qualityMessage(status: FoodQualityStatus): string {
    if (status === 'FRESH') return 'Food looks fresh and safe to donate'
    if (status === 'ABOUT_TO_SPOIL') return 'Food may spoil soon, post quickly!'
    return 'This food appears spoiled and cannot be posted'
  }

  async function runPhotoAnalysis(file: File) {
    if (!import.meta.env.VITE_GEMINI_API_KEY) {
      toast.error('Add VITE_GEMINI_API_KEY to your .env to enable food quality analysis.')
      setPhotoAnalysis(null)
      return
    }
    setAnalyzingPhoto(true)
    setPhotoAnalysis(null)
    try {
      const result = await analyzeFoodImageWithGemini(file)
      setPhotoAnalysis(result)
    } catch (err) {
      setPhotoAnalysis(null)
      toast.error(err instanceof Error ? err.message : 'Could not analyze image')
    } finally {
      setAnalyzingPhoto(false)
    }
  }

  async function onPhotoChange(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0] ?? null
    setPhotoFile(file)
    setPhotoAnalysis(null)
    if (file) void runPhotoAnalysis(file)
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!restaurantId) return
    if (photoFile && photoAnalysis?.status === 'SPOILED') {
      setError('This food appears spoiled and cannot be posted.')
      return
    }
    if (photoFile && analyzingPhoto) {
      setError('Please wait for food quality analysis to finish.')
      return
    }
    setSubmitting(true)
    setError(null)
    setSuccess(null)
    try {
      let photoDataUrl: string | undefined
      if (photoFile) {
        photoDataUrl = await fileToDataUrl(photoFile)
      }
      let lat: number | null = selectedCoords?.lat ?? null
      let lon: number | null = selectedCoords?.lon ?? null
      if (lat === null || lon === null) {
        const geo = await geocodeAddress(pickupAddress)
        if (geo) {
          lat = geo.lat
          lon = geo.lon
        }
      }

      const postRef = await addDoc(collection(db, 'foodPosts'), {
        restaurantId,
        foodName,
        quantity,
        pickupAddress,
        cookedTime,
        expiryTime,
        photoDataUrl: photoDataUrl || null,
        latitude: lat,
        longitude: lon,
        status: 'available',
        createdAt: serverTimestamp(),
        ...(photoFile && photoAnalysis
          ? {
              foodQuality: photoAnalysis.status,
              predictedSpoilHours: photoAnalysis.hoursUntilSpoil,
              geminiAnalysis: photoAnalysis.reason,
            }
          : {}),
      })

      try {
        const predictRes = await fetch(`${import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'}/api/predict-expiry`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            foodName,
            quantity,
            postedTime: new Date().toISOString(),
            cookedTime,
            expiryTime,
          }),
        })
        
        let finalRiskLevel = 'LOW';
        let updates: any = {};
        if (predictRes.ok) {
          const aiData = await predictRes.json()
          updates = { riskLevel: aiData.riskLevel, riskReason: aiData.reason, riskRecommendation: aiData.recommendation, safeHours: aiData.safeHours }
          finalRiskLevel = aiData.riskLevel;
          setAiRiskResult(aiData)
        }

        // Smart Assignment via Backend
        const matchRes = await fetch(`${import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'}/api/match`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            foodPost: {
              latitude: lat,
              longitude: lon,
              quantity,
              riskLevel: finalRiskLevel
            }
          }),
        })
        
        if (matchRes.ok) {
           const matchData = await matchRes.json()
           if (matchData.bestNgo?.id) {
               updates.assignedNgoId = matchData.bestNgo.id;
               const expiry = new Date();
               expiry.setMinutes(expiry.getMinutes() + 15);
               updates.assignmentExpiresAt = expiry.toISOString();
           }
        }
        
        if (Object.keys(updates).length > 0) {
            await updateDoc(doc(db, 'foodPosts', postRef.id), updates)
        }

      } catch (err) {
        // eslint-disable-next-line no-console
        console.error('Failed to run AI predictors', err)
      }

      setFoodName('')
      setQuantity('')
      setPickupAddress('')
      setAddressSuggestions([])
      setShowAddressDropdown(false)
      setSelectedCoords(null)
      setCookedTime('')
      setExpiryTime('')
      setPhotoFile(null)
      setPhotoAnalysis(null)
      setSuccess('Food post created successfully.')
      toast.success('Food post published')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create post')
      toast.error('Failed to publish food post')
    } finally {
      setSubmitting(false)
    }
  }

  if (loadingUser) {
    return (
      <RestaurantSidebarLayout title="Post Food">
        <div className="flex items-center gap-3 p-6">
          <Spinner />
          <span className="text-sm text-white/60">Loading dashboard...</span>
        </div>
      </RestaurantSidebarLayout>
    )
  }

  return (
    <RestaurantSidebarLayout title="Post Food">
      <main className="mx-auto w-full max-w-3xl">
        <section className="card-surface p-6 sm:p-8">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-white">Post Surplus Food</h2>
            <p className="mt-1 text-sm text-white/45">
              Fill this form so nearby NGOs can discover your available food.
            </p>
          </div>

          <form onSubmit={onSubmit} className="space-y-5">
            {/* Food Name */}
            <label className="block">
              <div className="mb-1.5 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-white/40">
                <FaUtensils className="text-purple-400" /> Food name
              </div>
              <input
                required
                value={foodName}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setFoodName(e.target.value)}
                className="glass-input"
                placeholder="Cooked rice and vegetables"
              />
            </label>

            {/* Quantity */}
            <label className="block">
              <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-white/40">Quantity</div>
              <input
                required
                value={quantity}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setQuantity(e.target.value)}
                className="glass-input"
                placeholder="25 meal boxes"
              />
            </label>

            {/* Address */}
            <label className="block">
              <div className="mb-1.5 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-white/40">
                <FaMapMarkerAlt className="text-orange-400" /> Pickup address
              </div>
              <div className="relative">
                <input
                  required
                  value={pickupAddress}
                  onFocus={() => setShowAddressDropdown(true)}
                  onBlur={() => setTimeout(() => setShowAddressDropdown(false), 150)}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => {
                    setPickupAddress(e.target.value)
                    setSelectedCoords(null)
                  }}
                  className="glass-input"
                  placeholder="123 Main Street, City"
                />
                {showAddressDropdown && addressSuggestions.length > 0 && (
                  <div
                    className="absolute z-20 mt-1 max-h-56 w-full overflow-y-auto"
                    style={{
                      borderRadius: 12,
                      border: '1px solid rgba(255,255,255,0.08)',
                      background: 'rgba(11,11,15,0.96)',
                      backdropFilter: 'blur(20px)',
                      boxShadow: '0 12px 32px rgba(0,0,0,0.5)',
                    }}
                  >
                    {addressSuggestions.map((s, idx) => (
                      <button
                        key={`${s.display_name}-${idx}`}
                        type="button"
                        onClick={() => {
                          setPickupAddress(s.display_name)
                          setSelectedCoords({ lat: Number(s.lat), lon: Number(s.lon) })
                          setShowAddressDropdown(false)
                        }}
                        className="block w-full border-b border-white/05 px-3 py-2.5 text-left text-xs text-white/70 hover:bg-white/06 hover:text-white/90 transition-all"
                      >
                        {s.display_name}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {selectedCoords && (
                <div className="mt-1.5 text-xs text-emerald-400/80">
                  ✓ Coordinates saved: {selectedCoords.lat.toFixed(5)}, {selectedCoords.lon.toFixed(5)}
                </div>
              )}
            </label>

            {/* Times (grid) */}
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block">
                <div className="mb-1.5 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-white/40">
                  <FaClock className="text-purple-400" /> Time cooked
                </div>
                <input
                  type="datetime-local"
                  required
                  value={cookedTime}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setCookedTime(e.target.value)}
                  className="glass-input"
                  style={{ colorScheme: 'dark' }}
                />
              </label>
              <label className="block">
                <div className="mb-1.5 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-white/40">
                  <FaClock className="text-orange-400" /> Estimated expiry
                </div>
                <input
                  type="datetime-local"
                  required
                  value={expiryTime}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setExpiryTime(e.target.value)}
                  className="glass-input"
                  style={{ colorScheme: 'dark' }}
                />
              </label>
              <label className="block">
                <div className="mb-1.5 inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-white/40">
                  <FaClock className="text-emerald-400" /> Auto-Analyze Time (24h)
                </div>
                <input
                  type="time"
                  required
                  value={cookingTime}
                  onChange={(e: ChangeEvent<HTMLInputElement>) => setCookingTime(e.target.value)}
                  className="glass-input"
                  style={{ colorScheme: 'dark' }}
                />
              </label>
            </div>



            {/* Photo */}
            <label className="block">
              <div className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-white/40">Photo (optional)</div>
              <input
                type="file"
                accept="image/*"
                onChange={onPhotoChange}
                className="glass-input text-sm text-white/60
                  file:mr-3 file:rounded-md file:border-0 file:bg-purple-600/20 file:px-3 file:py-1.5 
                  file:text-sm file:font-medium file:text-purple-300 hover:file:bg-purple-600/30"
              />
              {photoFile && photoPreviewUrl && (
                <div
                  className={[
                    'relative mt-3 overflow-hidden',
                    analyzingPhoto
                      ? 'border-white/20'
                      : photoAnalysis?.status === 'FRESH'
                        ? 'border-emerald-500/60'
                        : photoAnalysis?.status === 'ABOUT_TO_SPOIL'
                          ? 'border-amber-400/60'
                          : photoAnalysis?.status === 'SPOILED'
                            ? 'border-red-500/60'
                            : 'border-white/10',
                  ].join(' ')}
                  style={{
                    borderRadius: 12,
                    border: '2px solid',
                  }}
                >
                  <img
                    src={photoPreviewUrl}
                    alt="Food preview"
                    className="max-h-56 w-full object-contain"
                    style={{ background: 'rgba(255,255,255,0.04)' }}
                  />
                  {analyzingPhoto && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/60 backdrop-blur-sm">
                      <Spinner />
                      <span className="text-sm font-medium text-white/80">🔍 Analyzing food quality...</span>
                    </div>
                  )}
                  {!analyzingPhoto && photoAnalysis && (
                    <span
                      className={[
                        'absolute left-2 top-2 rounded-full px-2.5 py-0.5 text-xs font-bold shadow',
                        photoAnalysis.status === 'FRESH'
                          ? 'bg-emerald-600 text-white'
                          : photoAnalysis.status === 'ABOUT_TO_SPOIL'
                            ? 'bg-amber-500 text-white'
                            : 'bg-red-600 text-white',
                      ].join(' ')}
                    >
                      {photoAnalysis.status === 'FRESH'
                        ? '✅ FRESH'
                        : photoAnalysis.status === 'ABOUT_TO_SPOIL'
                          ? '⚠️ ABOUT TO SPOIL'
                          : '❌ SPOILED'}
                    </span>
                  )}
                </div>
              )}
              {!analyzingPhoto && photoAnalysis && (
                <div className="mt-2 space-y-1 text-sm">
                  <p
                    className={
                      photoAnalysis.status === 'FRESH'
                        ? 'font-medium text-emerald-400'
                        : photoAnalysis.status === 'ABOUT_TO_SPOIL'
                          ? 'font-medium text-amber-400'
                          : 'font-medium text-red-400'
                    }
                  >
                    {photoAnalysis.status === 'FRESH' && '✅ '}
                    {photoAnalysis.status === 'ABOUT_TO_SPOIL' && '⚠️ '}
                    {photoAnalysis.status === 'SPOILED' && '❌ '}
                    {qualityMessage(photoAnalysis.status)}
                  </p>
                  <p className="text-white/40">{photoAnalysis.reason}</p>
                </div>
              )}
            </label>

            {/* Alerts */}
            {error && <div className="alert-error">{error}</div>}
            {success && <div className="alert-success">{success}</div>}

            {/* Submit */}
            <button
              type="submit"
              disabled={
                submitting ||
                analyzingPhoto ||
                (!!photoFile && photoAnalysis?.status === 'SPOILED')
              }
              className="cta-btn w-full py-3 text-sm disabled:cursor-not-allowed disabled:opacity-50"
            >
              {submitting ? 'Posting...' : '🚀 Post Food'}
            </button>
          </form>

          {/* AI Risk Result */}
          {aiRiskResult && (
            <div
              className="mt-6 rounded-xl p-4"
              style={{
                border: `1px solid ${
                  aiRiskResult.riskLevel === 'CRITICAL' ? 'rgba(239,68,68,0.3)' :
                  aiRiskResult.riskLevel === 'HIGH'     ? 'rgba(249,115,22,0.3)' :
                  aiRiskResult.riskLevel === 'MEDIUM'   ? 'rgba(234,179,8,0.3)' :
                                                          'rgba(16,185,129,0.3)'
                }`,
                background:
                  aiRiskResult.riskLevel === 'CRITICAL' ? 'rgba(239,68,68,0.07)' :
                  aiRiskResult.riskLevel === 'HIGH'     ? 'rgba(249,115,22,0.07)' :
                  aiRiskResult.riskLevel === 'MEDIUM'   ? 'rgba(234,179,8,0.07)' :
                                                          'rgba(16,185,129,0.07)',
              }}
            >
              <h3 className={`flex items-center gap-2 text-sm font-bold ${
                aiRiskResult.safetyColor === 'red' || aiRiskResult.riskLevel === 'CRITICAL' ? 'text-red-400' :
                aiRiskResult.safetyColor === 'orange' || aiRiskResult.riskLevel === 'HIGH' ? 'text-orange-400' :
                aiRiskResult.safetyColor === 'yellow' || aiRiskResult.riskLevel === 'MEDIUM' ? 'text-yellow-400' :
                'text-emerald-400'
              }`}>
                🤖 AI Analysis: {aiRiskResult.safetyLabel || aiRiskResult.riskLevel} — {aiRiskResult.recommendation}
              </h3>
              <p className="mt-1 text-sm text-white/50">{aiRiskResult.reason}</p>
              {aiRiskResult.safeUntil && (
                <p className="mt-1 text-xs font-medium text-white/40">⏰ Safe until approx: {aiRiskResult.safeUntil}</p>
              )}
              {aiRiskResult.weatherInfo?.temperature !== undefined && aiRiskResult.weatherInfo?.temperature !== null && (
                <div className={`mt-3 rounded-lg border p-2 text-xs font-semibold ${
                  aiRiskResult.weatherInfo.temperature > 30 ? 'border-orange-500/30 bg-orange-500/5 text-orange-300' : 'border-emerald-500/30 bg-emerald-500/5 text-emerald-300'
                }`}>
                  🌡️ Local Temperature: {aiRiskResult.weatherInfo.temperature}°C ({aiRiskResult.weatherInfo.condition})
                  <div className="mt-0.5 opacity-60 font-normal">{aiRiskResult.weatherInfo.impact}</div>
                </div>
              )}
            </div>

          )}
        </section>
      </main>
    </RestaurantSidebarLayout>
  )
}
