import { onAuthStateChanged } from 'firebase/auth'
import { collection, deleteDoc, doc, getDocs, query, updateDoc, where } from 'firebase/firestore'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { RestaurantSidebarLayout } from '../components/restaurant/RestaurantSidebarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type Post = {
  id: string
  foodName: string
  quantity: string
  expiryTime: string
  status?: string
  createdAt?: { seconds?: number }
  photoDataUrl?: string | null
  foodQuality?: string
  predictedSpoilHours?: number
  geminiAnalysis?: string
}

function getStatus(post: Post) {
  if (post.status === 'collected') return 'Collected'
  if (post.status === 'claimed') return 'Claimed'
  const expiry = new Date(post.expiryTime).getTime()
  if (!Number.isNaN(expiry) && expiry < Date.now()) return 'Expired'
  return 'Available'
}

function countdown(expiryTime: string) {
  const ms = new Date(expiryTime).getTime() - Date.now()
  if (ms <= 0) return 'Expired'
  const h = Math.floor(ms / (1000 * 60 * 60))
  const m = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60))
  return `${h}h ${m}m left`
}

function defaultFoodImage(foodName: string) {
  return `https://source.unsplash.com/400x200/?${encodeURIComponent(foodName || 'food')},food`
}

function statusBadgeClass(status: string) {
  if (status === 'Available') return 'badge badge-green'
  if (status === 'Claimed')   return 'badge badge-amber'
  if (status === 'Collected') return 'badge badge-purple'
  return 'badge badge-slate'
}

export function RestaurantPostsPage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [posts, setPosts] = useState<Post[]>([])
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [reportingId, setReportingId] = useState<string | null>(null)
  const [brokenImagePostIds, setBrokenImagePostIds] = useState<Record<string, boolean>>({})

  async function load(uid: string) {
    setLoading(true)
    try {
      const snap = await getDocs(query(collection(db, 'foodPosts'), where('restaurantId', '==', uid)))
      const rawItems: Post[] = snap.docs
        .map((d) => ({ id: d.id, ...(d.data() as Omit<Post, 'id'>) }))
        .sort((a, b) => (b.createdAt?.seconds ?? 0) - (a.createdAt?.seconds ?? 0))

      const fixedItems = await Promise.all(
        rawItems.map(async (post) => {
          const current = String(post.photoDataUrl || '')
          const lower = current.toLowerCase()
          const containsAnime = lower.includes('anime') || lower.includes('cartoon')
          if (containsAnime) {
            const replacement = defaultFoodImage(post.foodName)
            try {
              await updateDoc(doc(db, 'foodPosts', post.id), { photoDataUrl: replacement })
            } catch {
              // Keep UI working even if update fails.
            }
            return { ...post, photoDataUrl: replacement }
          }
          return post
        }),
      )

      setBrokenImagePostIds({})
      setPosts(fixedItems)
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to load posts')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user: any) => {
      if (!user) {
        navigate('/login')
        return
      }
      void load(user.uid)
    })
    return () => unsub()
  }, [navigate])

  async function removePost(id: string) {
    setDeletingId(id)
    try {
      await deleteDoc(doc(db, 'foodPosts', id))
      setPosts((prev) => prev.filter((p) => p.id !== id))
      toast.success('Post deleted')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete post')
    } finally {
      setDeletingId(null)
    }
  }

  async function reportNoShow(post: Post) {
    if (!window.confirm(`Are you sure you want to mark ${post.foodName} as abandoned by the NGO? It will be put back on the public board.`)) return;
    setReportingId(post.id)
    try {
      const fullPost = post as any;
      const ngoToBan = fullPost.acceptedBy || fullPost.claimedBy || 'unknown';
      const declinedList = Array.isArray(fullPost.declinedByNgos) ? [...fullPost.declinedByNgos, ngoToBan] : [ngoToBan];
      
      await updateDoc(doc(db, 'foodPosts', post.id), {
        status: 'available',
        acceptedBy: null,
        claimedBy: null,
        assignedNgoId: 'public',
        declinedByNgos: declinedList,
        restaurantNotifiedOfClaim: false
      })
      
      toast.success('Post reverted to Available on the public board!')
      setPosts(prev => prev.map(p => p.id === post.id ? { ...p, status: 'available' } : p))
    } catch(err) {
      toast.error('Failed to report no-show')
    } finally {
      setReportingId(null)
    }
  }

  async function handleImageError(post: Post) {
    if (brokenImagePostIds[post.id]) return
    const replacement = defaultFoodImage(post.foodName)
    setBrokenImagePostIds((prev) => ({ ...prev, [post.id]: true }))
    setPosts((prev) => prev.map((p) => (p.id === post.id ? { ...p, photoDataUrl: replacement } : p)))
    try {
      await updateDoc(doc(db, 'foodPosts', post.id), { photoDataUrl: replacement })
    } catch {
      // Avoid surfacing noisy errors for image fallback save.
    }
  }

  return (
    <RestaurantSidebarLayout title="My Posts">
      {loading ? (
        <div className="flex items-center gap-3 p-4">
          <Spinner size="sm" />
          <span className="text-sm text-white/50">Loading posts...</span>
        </div>
      ) : posts.length === 0 ? (
        <div className="card-surface p-8 text-center">
          <p className="text-3xl mb-3">📭</p>
          <p className="text-white/40 text-sm">No posts yet. Post some food to get started!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((post) => {
            const status = getStatus(post)
            const canDelete = status === 'Available'
            const imageSrc = post.photoDataUrl || defaultFoodImage(post.foodName)
            return (
              <article
                key={post.id}
                className="card-surface overflow-hidden p-0 flex flex-col"
                style={{ padding: 0 }}
              >
                {/* Image */}
                <div className="relative overflow-hidden" style={{ height: 180 }}>
                  <img
                    src={imageSrc}
                    alt={post.foodName}
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    onError={() => void handleImageError(post)}
                  />
                  {/* overlay gradient */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                  <span className={`absolute right-3 top-3 ${statusBadgeClass(status)}`}>
                    {status}
                  </span>
                </div>

                {/* Content */}
                <div className="flex flex-col flex-1 p-4 gap-2">
                  <div className="font-semibold text-white/90">
                    {post.foodName}
                    <span className="ml-2 text-sm font-normal text-white/45">· {post.quantity}</span>
                  </div>
                  <div className="text-xs text-white/35">
                    Posted:{' '}
                    {post.createdAt?.seconds
                      ? new Date(post.createdAt.seconds * 1000).toLocaleString()
                      : 'N/A'}
                  </div>
                  <div className="text-xs text-white/35">Expiry: {post.expiryTime}</div>
                  <div className="text-xs font-semibold text-orange-400">
                    ⏱ {countdown(post.expiryTime)}
                  </div>
                  {typeof post.predictedSpoilHours === 'number' && !Number.isNaN(post.predictedSpoilHours) && (
                    <div className="badge badge-slate self-start text-[10px]">
                      🕐 Spoils in ~{Math.round(post.predictedSpoilHours)}h
                    </div>
                  )}

                  {/* Actions */}
                  <div className="mt-auto pt-3 flex flex-wrap gap-2">
                    {canDelete && (
                      <button
                        type="button"
                        onClick={() => void removePost(post.id)}
                        disabled={deletingId === post.id}
                        className="rounded-xl border border-red-500/25 bg-red-500/10 px-3 py-2 text-sm font-semibold text-red-400 hover:bg-red-500/18 hover:border-red-400/40 transition-all disabled:opacity-50"
                      >
                        {deletingId === post.id ? 'Deleting...' : 'Delete'}
                      </button>
                    )}
                    {status === 'Claimed' && (
                      <button
                        type="button"
                        onClick={() => void reportNoShow(post)}
                        disabled={reportingId === post.id}
                        className="rounded-xl border border-amber-500/25 bg-amber-500/10 px-3 py-2 text-sm font-semibold text-amber-400 hover:bg-amber-500/18 hover:border-amber-400/40 transition-all disabled:opacity-50"
                      >
                        {reportingId === post.id ? 'Reporting...' : 'Report NGO No-Show'}
                      </button>
                    )}
                  </div>
                </div>
              </article>
            )
          })}
        </div>
      )}
    </RestaurantSidebarLayout>
  )
}
