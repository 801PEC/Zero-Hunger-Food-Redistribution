import { FiMoon, FiSun } from 'react-icons/fi'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useTheme } from '../lib/theme'
import logo from '../assets/logo.png'

export function HomePage() {
  const navigate = useNavigate()
  const { theme, toggleTheme } = useTheme()
  const [storyStarted, setStoryStarted] = useState(false)
  const [failedStepImages, setFailedStepImages] = useState<Record<number, boolean>>({})
  const storySectionRef = useRef<HTMLElement | null>(null)

  const steps = useMemo(
    () => [
      {
        step: 1,
        image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=80&h=80&fit=crop',
        title: 'Post Surplus Food',
        description: 'Restaurants list available food with quantity, location and pickup time.',
      },
      {
        step: 2,
        image: 'https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=80&h=80&fit=crop',
        title: 'AI Finds Best Match',
        description: 'Smart algorithm instantly matches the post to the nearest available NGO.',
      },
      {
        step: 3,
        image: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?w=80&h=80&fit=crop',
        title: 'Food Gets Delivered',
        description: 'NGO collects and distributes food to communities that need it most.',
      },
    ],
    [],
  )

  useEffect(() => {
    const target = storySectionRef.current
    if (!target) return
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setStoryStarted(true)
            observer.disconnect()
          }
        })
      },
      { threshold: 0.25 },
    )
    observer.observe(target)
    return () => observer.disconnect()
  }, [])

  return (
    <div className="glass-page min-h-screen">
      {/* ── Navbar ────────────────────────────── */}
      <header className="glass-navbar sticky top-0 z-20">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
          <button type="button" onClick={() => navigate('/')} className="inline-flex items-center gap-2.5 group">
            <div className="relative h-8 w-8 shrink-0">
              <div className="absolute inset-0 rounded-full bg-purple-600/20 blur-md group-hover:bg-purple-500/30 transition-all duration-300" />
              <img src={logo} alt="Zero Hunger" className="relative h-8 w-auto object-contain" />
            </div>
            <span className="text-base font-bold text-white">Zero Hunger</span>
          </button>

          <div className="flex items-center gap-2">
            <Link
              to="/contact"
              className="rounded-lg px-3 py-2 text-sm font-medium text-white/50 hover:text-white/90 hover:bg-white/06 transition-all"
            >
              Contact
            </Link>
            <button
              type="button"
              onClick={toggleTheme}
              className="rounded-lg border border-white/08 bg-white/04 p-2 text-white/50 hover:text-white hover:bg-white/10 transition-all"
            >
              {theme === 'dark' ? <FiSun className="h-4 w-4" /> : <FiMoon className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={() => navigate('/login')}
              className="cta-btn text-sm"
            >
              Login
            </button>
          </div>
        </div>
      </header>

      {/* ── Hero ──────────────────────────────── */}
      <main className="mx-auto flex min-h-[calc(100vh-64px)] w-full max-w-6xl flex-col justify-center px-4 py-10 sm:px-6 sm:py-12">
        <section className="py-8 text-center dark-hero-glow">
          <div className="inline-flex items-center gap-2 rounded-full border border-purple-500/20 bg-purple-500/10 px-3 py-1 text-xs font-medium text-purple-300 mb-6">
            <span className="pulse-dot" />
            <span>Live · Connecting food donors right now</span>
          </div>

          <h1 className="glow-text mx-auto max-w-4xl text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl leading-tight">
            Turn Food Waste<br />Into Meals
          </h1>

          <p className="mx-auto mt-6 max-w-2xl text-base text-white/50 sm:text-lg leading-relaxed">
            Connecting restaurants with NGOs to rescue surplus food and feed communities in need.
          </p>

          <div className="mt-8 flex items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => navigate('/login')}
              className="cta-btn px-6 py-3 text-sm"
            >
              Get Started →
            </button>
            <Link
              to="/contact"
              className="soft-btn px-6 py-3 text-sm"
            >
              Learn More
            </Link>
          </div>
        </section>

        {/* ── Divider ───────────────────────── */}
        <div className="glass-divider my-6" />

        {/* ── How It Works ──────────────────── */}
        <section ref={storySectionRef} className="mx-auto max-w-6xl py-6 sm:py-8">
          <h2 className="mt-1 text-center text-2xl font-bold text-white/90">
            How It Works
          </h2>
          <p className="mt-2 text-center text-sm text-white/40">Three simple steps to make an impact</p>

          <div className="mt-8 grid gap-3 md:grid-cols-[1fr_auto_1fr_auto_1fr] md:items-center">
            {steps.map((item, idx) => (
              <div key={item.title} className="contents">
                <article
                  className={[
                    'glass-card group relative overflow-hidden p-5 transition-all duration-300',
                    storyStarted ? 'fb-story-card-enter' : 'opacity-0 translate-y-6',
                    idx === 0 ? 'md:col-start-1' : idx === 1 ? 'md:col-start-3' : 'md:col-start-5',
                  ].join(' ')}
                  style={storyStarted ? { animationDelay: `${idx * 200}ms` } : undefined}
                >
                  <span className="fb-story-card-glow" aria-hidden />
                  <div className="inline-flex items-center gap-3">
                    <span className="fb-story-image-ring">
                      {failedStepImages[item.step] ? (
                        <span className="grid h-[72px] w-[72px] place-items-center rounded-full bg-purple-700 text-xl font-bold text-white">
                          {item.step}
                        </span>
                      ) : (
                        <img
                          src={item.image}
                          alt={item.title}
                          className="h-[72px] w-[72px] rounded-full object-cover"
                          loading="lazy"
                          onError={() =>
                            setFailedStepImages((prev) => ({
                              ...prev,
                              [item.step]: true,
                            }))
                          }
                        />
                      )}
                    </span>
                    <span className="text-[10px] font-semibold uppercase tracking-[0.22em] text-purple-400">
                      Step {item.step}
                    </span>
                  </div>
                  <h3 className="mt-4 text-lg font-bold text-white/90">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-white/45">{item.description}</p>
                </article>

                {idx < 2 ? (
                  <div
                    className={[
                      'relative hidden h-6 w-20 items-center justify-center self-center md:flex',
                      idx === 0 ? 'md:col-start-2' : 'md:col-start-4',
                    ].join(' ')}
                    aria-hidden
                  >
                    <span
                      className={[
                        'absolute left-0 top-1/2 h-[2px] w-full -translate-y-1/2 rounded-full bg-gradient-to-r from-purple-500 via-violet-500 to-blue-500',
                        storyStarted ? 'fb-story-arrow-line' : 'origin-left scale-x-0',
                      ].join(' ')}
                      style={storyStarted ? { animationDelay: `${idx * 300 + 150}ms` } : undefined}
                    />
                    <span
                      className={[
                        'absolute top-1/2 h-2.5 w-2.5 -translate-y-1/2 rounded-full bg-purple-300 shadow-[0_0_12px_rgba(124,58,237,0.9)]',
                        storyStarted ? 'fb-story-arrow-dot' : 'opacity-0',
                      ].join(' ')}
                    />
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* ── Footer ────────────────────────────── */}
      <footer className="border-t border-white/06 bg-white/02">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center gap-2 px-4 py-8 text-center sm:px-6">
          <div className="inline-flex items-center gap-2 text-sm font-semibold text-white/80">
            <img src={logo} alt="Logo" className="h-6 w-auto object-contain opacity-70" />
            <span>Zero Hunger © 2026</span>
          </div>
          <p className="text-sm text-white/30">Fighting hunger, reducing waste 🌱</p>
        </div>
      </footer>
    </div>
  )
}
