import { useEffect, useMemo, useState } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import {
  collection,
  doc,
  getDocs,
  serverTimestamp,
  updateDoc,
} from 'firebase/firestore'
import { CircleMarker, MapContainer, Popup, TileLayer } from 'react-leaflet'
import type { LatLngExpression } from 'leaflet'
import toast from 'react-hot-toast'
import { FaMapMarkerAlt, FaRegClock } from 'react-icons/fa'
import { useNavigate } from 'react-router-dom'
import { NGOSidebarLayout } from '../components/ngo/NGOSidebarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type FoodPost = {
  id: string
  foodName: string
  quantity: string
  pickupAddress: string
  expiryTime: string
  status: 'available' | 'claimed' | 'expired'
  restaurantId: string
  photoDataUrl?: string | null
  latitude?: number
  longitude?: number
  foodQuality?: string
  predictedSpoilHours?: number
  geminiAnalysis?: string
  riskLevel?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
  riskReason?: string
  riskRecommendation?: string
  safeHours?: number
  assignedNgoId?: string
  assignmentExpiresAt?: string
  cookingTime?: string
  safeUntil?: string
}

type Coords = { lat: number; lng: number } | null

type MatchResult = {
  bestMatch: string
  bestNgo?: {
    id: string
    name?: string
    ngoName?: string
    location?: string
    latitude?: number
    longitude?: number
    distanceKm?: number
  }
  reason: string
}
type NGOProfile = {
  id: string
  ngoName?: string
  name?: string
  latitude?: number
  longitude?: number
  capacityAvailable?: number
  capacity?: number
  dailyCapacity?: number
}

const DEFAULT_CENTER: LatLngExpression = [20.5937, 78.9629]
const DEFAULT_ZOOM = 5
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000'
const DEFAULT_FOOD_IMAGE =
  'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=200&fit=crop'

async function geocodeAddress(address: string) {
  const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`
  const resp = await fetch(url, {
    headers: { Accept: 'application/json' },
  })
  if (!resp.ok) return null
  const data = (await resp.json()) as Array<{ lat: string; lon: string }>
  if (!data.length) return null
  const lat = Number(data[0].lat)
  const lon = Number(data[0].lon)
  if (Number.isNaN(lat) || Number.isNaN(lon)) return null
  return { lat, lon }
}

function getRiskBadge(riskLevel: string) {
  if (riskLevel === 'CRITICAL') return <span className="badge badge-red animate-pulse">🚨 Critical!</span>
  if (riskLevel === 'HIGH')     return <span className="badge badge-red">⚠️ Urgent</span>
  if (riskLevel === 'MEDIUM')   return <span className="badge badge-amber">⚡ Use Soon</span>
  return <span className="badge badge-green">✓ Fresh</span>
}

export function NGODashboard() {
  const navigate = useNavigate()
  const [ngoId, setNgoId] = useState<string | null>(null)
  const [posts, setPosts] = useState<FoodPost[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [acceptingPostId, setAcceptingPostId] = useState<string | null>(null)
  const [matchingPostId, setMatchingPostId] = useState<string | null>(null)
  const [matchResult, setMatchResult] = useState<MatchResult | null>(null)
  const [matchForPostId, setMatchForPostId] = useState<string | null>(null)
  const [confirmPost, setConfirmPost] = useState<FoodPost | null>(null)
  const [userCoords, setUserCoords] = useState<Coords>(null)
  const [ngoProfiles, setNgoProfiles] = useState<NGOProfile[]>([])
  const [brokenImagePostIds, setBrokenImagePostIds] = useState<Record<string, boolean>>({})

  function distanceKmFromUser(post: FoodPost) {
    if (!userCoords || post.latitude === undefined || post.longitude === undefined) return null
    const R = 6371
    const dLat = ((post.latitude - userCoords.lat) * Math.PI) / 180
    const dLng = ((post.longitude - userCoords.lng) * Math.PI) / 180
    const aa =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((userCoords.lat * Math.PI) / 180) *
        Math.cos((post.latitude * Math.PI) / 180) *
        Math.sin(dLng / 2) ** 2
    const c = 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa))
    return (R * c).toFixed(1)
  }

  async function loadAvailablePosts() {
    setLoading(true)
    setError(null)
    try {
      const snap = await getDocs(collection(db, 'foodPosts'))
      const rawPosts: FoodPost[] = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<FoodPost, 'id'>),
      }))

      const hydrated = await Promise.all(
        rawPosts.map(async (post) => {
          let updated = { ...post }
          let needsUpdate = false

          if (typeof post.latitude !== 'number' || typeof post.longitude !== 'number') {
            const geo = await geocodeAddress(post.pickupAddress)
            if (geo) {
              updated.latitude = geo.lat
              updated.longitude = geo.lon
              needsUpdate = true
            }
          }

          if (!updated.riskLevel && updated.status === 'available') {
            try {
              const predictRes = await fetch(`${API_BASE_URL}/api/predict-expiry`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  foodName: updated.foodName,
                  quantity: updated.quantity,
                  postedTime: new Date().toISOString(),
                  expiryTime: updated.expiryTime,
                }),
              })
              if (predictRes.ok) {
                const aiData = await predictRes.json()
                updated.riskLevel = aiData.riskLevel
                updated.riskReason = aiData.reason
                updated.riskRecommendation = aiData.recommendation
                updated.safeHours = aiData.safeHours
                needsUpdate = true
              }
            } catch (err) {
              // ignore
            }
          }

          if (needsUpdate) {
            try {
              await updateDoc(doc(db, 'foodPosts', post.id), {
                ...(updated.latitude && updated.longitude ? { latitude: updated.latitude, longitude: updated.longitude } : {}),
                ...(updated.riskLevel ? { riskLevel: updated.riskLevel, riskReason: updated.riskReason, riskRecommendation: updated.riskRecommendation, safeHours: updated.safeHours } : {}),
              })
            } catch {
              // Keep UI functional even if Firestore update fails.
            }
          }

          return updated
        }),
      )

      setPosts(hydrated)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load available posts')
      toast.error('Failed to load available posts')
    } finally {
      setLoading(false)
    }
  }

  async function loadNgoProfiles() {
    try {
      const snap = await getDocs(collection(db, 'ngoProfiles'))
      const ngos: NGOProfile[] = snap.docs.map((d) => ({ ...(d.data() as NGOProfile), id: d.id }))
      setNgoProfiles(ngos)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load NGO profiles')
      toast.error('Failed to load NGO profiles')
    }
  }

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user: any) => {
      if (!user) {
        navigate('/')
        return
      }
      setNgoId(user.uid)
      void loadAvailablePosts()
      void loadNgoProfiles()
    })
    return () => unsub()
  }, [navigate])

  useEffect(() => {
    if (!navigator.geolocation) return
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude })
      },
      () => undefined,
      { maximumAge: 120000, timeout: 7000 },
    )
  }, [])

  async function acceptPost(postId: string) {
    setAcceptingPostId(postId)
    setError(null)
    try {
      if (!ngoId) {
        throw new Error('You are not authenticated. Please log in again.')
      }

      try {
        await updateDoc(doc(db, 'foodPosts', postId), {
          status: 'claimed',
          acceptedBy: ngoId,
          acceptedAt: new Date().toISOString(),
          claimedBy: ngoId,
          claimedAt: serverTimestamp(),
        })
      } catch (err) {
        throw new Error(
          err instanceof Error ? err.message : 'Failed updating post status in Firestore',
        )
      }

      setPosts((prev) => prev.filter((p) => p.id !== postId))
      toast.success('Food post claimed successfully!')
      setConfirmPost(null)
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to accept post'
      setError(msg)
      toast.error(msg)
    } finally {
      setAcceptingPostId(null)
    }
  }

  async function findBestMatch(post: FoodPost) {
    setMatchingPostId(post.id)
    setError(null)
    setMatchResult(null)
    setMatchForPostId(post.id)
    try {
      const resp = await fetch(`${API_BASE_URL}/api/match`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          foodPost: {
            id: post.id,
            name: post.foodName,
            quantity: post.quantity,
            location: post.pickupAddress,
            expiry: post.expiryTime,
            latitude: post.latitude,
            longitude: post.longitude,
          },
          nearbyNgos: ngoProfiles,
        }),
      })
      const data = await resp.json()
      if (!resp.ok) {
        throw new Error(data?.error || 'Failed to get recommendation')
      }
      setMatchResult(data as MatchResult)
      toast.success('Best match found')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to get recommendation')
      toast.error('Unable to generate match recommendation')
    } finally {
      setMatchingPostId(null)
    }
  }

  const mapCenter: LatLngExpression = DEFAULT_CENTER
  const riskWeights: Record<string, number> = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 }
  const listPosts = posts.filter((p) => {
    if (p.status !== 'available') return false;
    
    if (p.assignedNgoId && p.assignedNgoId !== ngoId && p.assignedNgoId !== 'public') {
      const expiresMs = p.assignmentExpiresAt ? new Date(p.assignmentExpiresAt).getTime() : 0;
      if (expiresMs > Date.now()) {
        return false;
      }
    }
    return true;
  }).sort((a, b) => {
    const wA = riskWeights[a.riskLevel || 'LOW'] || 0
    const wB = riskWeights[b.riskLevel || 'LOW'] || 0
    return wB - wA
  })

  const mappablePosts = useMemo(
    () =>
      listPosts.filter(
        (p) => typeof p.latitude === 'number' && typeof p.longitude === 'number',
      ),
    [listPosts],
  )

  const hasCritical = listPosts.some((p) => p.riskLevel === 'CRITICAL')

  function getPostMapStatus(post: FoodPost) {
    const expiryMs = new Date(post.expiryTime).getTime()
    if (!Number.isNaN(expiryMs) && expiryMs < Date.now()) return 'expired'
    if (post.status === 'claimed') return 'claimed'
    return 'available'
  }

  function getPinColor(status: 'available' | 'claimed' | 'expired') {
    if (status === 'expired') return '#ef4444'
    if (status === 'claimed') return '#6b7280'
    return '#7c3aed'
  }

  return (
    <NGOSidebarLayout title="Food Map">
      <main className="mx-auto w-full max-w-7xl">
        {error && <div className="alert-error mb-4">{error}</div>}

        {loading ? (
          <div className="card-surface flex items-center gap-3 p-6">
            <Spinner />
            <span className="text-sm text-white/50">Loading available posts...</span>
          </div>
        ) : (
          <>
            <div className="mb-4 flex items-center gap-3 text-sm text-white/40">
              <span>
                Available posts: <strong className="text-white/70">{listPosts.length}</strong>
              </span>
              <span className="h-3 w-px bg-white/10" />
              <span>
                Pins on map: <strong className="text-white/70">{mappablePosts.length}</strong>
              </span>
              {hasCritical && (
                <span className="badge badge-red animate-pulse ml-auto">⚠️ Urgent pickups present</span>
              )}
            </div>

            <div className="grid gap-4 lg:grid-cols-[380px_1fr]">
              {/* Posts List */}
              <section className="card-surface max-h-[640px] overflow-y-auto" style={{ padding: 0 }}>
                <div className="sticky top-0 border-b border-white/06 px-4 py-3"
                  style={{ background: 'rgba(11,11,15,0.9)', backdropFilter: 'blur(12px)' }}>
                  <h2 className="text-base font-semibold text-white/80">Nearby Food Posts</h2>
                </div>

                <div className="space-y-3 p-4">
                  {listPosts.length === 0 && (
                    <p className="text-sm text-white/35 py-4 text-center">No available posts right now.</p>
                  )}
                  {listPosts.map((post) => (
                    <article
                      key={post.id}
                      className="glass-card overflow-hidden"
                      style={{ padding: 0, borderRadius: 14 }}
                    >
                      {/* Food image */}
                      <div className="relative overflow-hidden" style={{ height: 120 }}>
                        {brokenImagePostIds[post.id] ? (
                          <div className="grid h-full w-full place-items-center text-4xl"
                            style={{ background: 'rgba(255,255,255,0.04)' }}>
                            🍽️
                          </div>
                        ) : (
                          <img
                            src={post.photoDataUrl || DEFAULT_FOOD_IMAGE}
                            alt={post.foodName}
                            className="h-full w-full object-cover"
                            onError={() =>
                              setBrokenImagePostIds((prev) => ({ ...prev, [post.id]: true }))
                            }
                          />
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                        {post.riskLevel && (
                          <div className="absolute right-2 top-2">
                            {getRiskBadge(post.riskLevel)}
                          </div>
                        )}
                      </div>

                      {/* Content */}
                      <div className="p-3 space-y-1.5">
                        <div className="font-semibold text-white/90 text-sm">{post.foodName}</div>
                        <div className="text-xs text-white/45">{post.quantity}</div>
                        <div className="text-xs text-white/35 inline-flex items-center gap-1">
                          <FaMapMarkerAlt className="text-purple-400/60" />
                          <span className="truncate max-w-[260px]">{post.pickupAddress}</span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 pt-0.5">
                          {distanceKmFromUser(post) && (
                            <span className="badge badge-purple text-[10px]">
                              📍 {distanceKmFromUser(post)} km
                            </span>
                          )}
                          <span className="inline-flex items-center gap-1 text-xs text-red-400/80">
                            <FaRegClock className="shrink-0" />
                            {post.expiryTime}
                          </span>
                        </div>

                        {typeof post.predictedSpoilHours === 'number' && !Number.isNaN(post.predictedSpoilHours) && (
                          <div className="text-xs text-white/40">
                            🕐 Predicted to spoil in {Math.round(post.predictedSpoilHours)} hours
                          </div>
                        )}

                        {post.cookingTime && (
                           <div className="text-xs text-white/40">
                             🍳 Cooked at: {post.cookingTime}
                           </div>
                        )}
                        {post.safeUntil && (
                           <div className="text-[10px] font-bold text-emerald-400/80 uppercase tracking-tighter">
                             🛡️ Safe Until: {post.safeUntil}
                           </div>
                        )}


                        {/* Actions */}
                        <div className="grid grid-cols-2 gap-2 pt-2">
                          <button
                            type="button"
                            disabled={acceptingPostId === post.id}
                            onClick={() => setConfirmPost(post)}
                            className="cta-btn py-2 text-xs disabled:opacity-50"
                            style={{
                              background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
                              boxShadow: '0 3px 12px rgba(5,150,105,0.28)',
                            }}
                          >
                            {acceptingPostId === post.id ? 'Accepting...' : '✓ Accept'}
                          </button>
                          <button
                            type="button"
                            disabled={matchingPostId === post.id}
                            onClick={() => void findBestMatch(post)}
                            className="cta-btn py-2 text-xs disabled:opacity-50"
                          >
                            {matchingPostId === post.id ? 'Finding...' : '🤖 Best Match'}
                          </button>
                        </div>

                        {/* Match Result */}
                        {matchResult && matchForPostId === post.id && (
                          <div className="mt-2 rounded-xl border border-purple-500/25 bg-purple-500/08 p-3">
                            <div className="text-xs font-semibold text-purple-400 mb-1">Best Match Recommendation</div>
                            <div className="text-sm font-medium text-white/80">{matchResult.bestMatch}</div>
                            <div className="text-xs text-white/45 mt-0.5">{matchResult.reason}</div>
                          </div>
                        )}
                      </div>
                    </article>
                  ))}
                </div>
              </section>

              {/* Map */}
              <div className="card-surface relative overflow-hidden" style={{ padding: 0, borderRadius: 16, minHeight: 400 }}>
                <MapContainer
                  center={mapCenter}
                  zoom={DEFAULT_ZOOM}
                  className="h-[420px] min-h-[400px] w-full sm:h-[640px]"
                  scrollWheelZoom
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />

                  {mappablePosts.map((post) => {
                    const pinStatus = getPostMapStatus(post)
                    return (
                      <CircleMarker
                        key={post.id}
                        center={[post.latitude as number, post.longitude as number]}
                        radius={10}
                        pathOptions={{
                          color: '#ffffff',
                          weight: 2,
                          fillColor: getPinColor(pinStatus),
                          fillOpacity: 1,
                        }}
                      >
                        <Popup>
                          <div className="min-w-52 space-y-1 text-sm">
                            <div className="font-semibold text-slate-900">{post.foodName}</div>
                            <div>Quantity: {post.quantity}</div>
                            <div>Expiry: {post.expiryTime}</div>
                            {typeof post.predictedSpoilHours === 'number' && !Number.isNaN(post.predictedSpoilHours) && (
                              <div className="text-xs text-slate-600">
                                🕐 Predicted to spoil in {Math.round(post.predictedSpoilHours)} hours
                              </div>
                            )}
                            <button
                              type="button"
                              onClick={() => toast(`Details: ${post.foodName} • ${post.pickupAddress}`)}
                              className="mt-2 w-full rounded-md bg-slate-900 px-3 py-1.5 text-white hover:bg-slate-800"
                            >
                              View Details
                            </button>
                          </div>
                        </Popup>
                      </CircleMarker>
                    )
                  })}
                </MapContainer>

                {posts.length === 0 && (
                  <div className="pointer-events-none absolute inset-0 z-[500] grid place-items-center bg-black/60 backdrop-blur-sm">
                    <p className="rounded-xl border border-white/08 bg-white/06 px-4 py-2.5 text-sm font-medium text-white/70 shadow-sm">
                      No food posts nearby yet
                    </p>
                  </div>
                )}
              </div>
            </div>

            {posts.length > mappablePosts.length && (
              <p className="mt-3 text-xs text-white/30">
                Some posts are missing map coordinates and could not be pinned automatically.
              </p>
            )}
          </>
        )}
      </main>

      {/* Confirm Pickup Modal */}
      {confirmPost && (
        <div className="glass-overlay">
          <div
            className="w-full max-w-md animate-fade-up"
            style={{
              borderRadius: 20,
              border: '1px solid rgba(255,255,255,0.09)',
              background: 'rgba(12,12,20,0.95)',
              boxShadow: '0 24px 48px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.07)',
              backdropFilter: 'blur(24px)',
              WebkitBackdropFilter: 'blur(24px)',
              padding: 28,
            }}
          >
            <h3 className="text-lg font-semibold text-white mb-4">Confirm Pickup</h3>

            <div
              className="space-y-2 rounded-xl p-4"
              style={{ border: '1px solid rgba(255,255,255,0.07)', background: 'rgba(255,255,255,0.03)' }}
            >
              <p className="text-sm text-white/60">
                <span className="font-medium text-white/80">Food:</span> {confirmPost.foodName}
              </p>
              <p className="text-sm text-white/60">
                <span className="font-medium text-white/80">Quantity:</span> {confirmPost.quantity}
              </p>
              <p className="text-sm text-white/60">
                <span className="font-medium text-white/80">Expiry:</span> {confirmPost.expiryTime}
              </p>
            </div>

            <div className="mt-5 flex justify-end gap-3">
              <button
                type="button"
                onClick={() => void acceptPost(confirmPost.id)}
                disabled={acceptingPostId === confirmPost.id}
                className="cta-btn px-4 py-2.5 text-sm disabled:opacity-50"
                style={{
                  background: 'linear-gradient(135deg, #059669 0%, #047857 100%)',
                  boxShadow: '0 4px 16px rgba(5,150,105,0.3)',
                }}
              >
                {acceptingPostId === confirmPost.id ? 'Accepting...' : '✓ Confirm'}
              </button>
              <button
                type="button"
                onClick={() => setConfirmPost(null)}
                className="soft-btn px-4 py-2.5 text-sm"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </NGOSidebarLayout>
  )
}
