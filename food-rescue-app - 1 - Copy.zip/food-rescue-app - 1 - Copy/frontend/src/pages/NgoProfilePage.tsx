// NgoProfilePage.tsx reformatted and polished
import { onAuthStateChanged } from 'firebase/auth'
import { collection, doc, getDoc, getDocs, query, setDoc, where } from 'firebase/firestore'
import { useEffect, useMemo, useState } from 'react'
import toast from 'react-hot-toast'
import { useNavigate } from 'react-router-dom'
import { NGOSidebarLayout } from '../components/ngo/NGOSidebarLayout'
import { Spinner } from '../components/Spinner'
import { auth, db } from '../lib/firebase'

type UserProfile = {
  email?: string
  name?: string
  ngoName?: string
  phone?: string
  serviceArea?: string
  capacity?: string
  address?: string
  description?: string
  photoDataUrl?: string
}

type AcceptedPost = { quantity: string; status?: string }

type ProfileForm = {
  ngoName: string
  email: string
  phone: string
  serviceArea: string
  capacity: string
  description: string
  photoDataUrl: string
}

function parseMeals(quantity: string) {
  const match = quantity?.match(/(\d+(\.\d+)?)/)
  if (!match) return 0
  const n = Number(match[1])
  return Number.isNaN(n) ? 0 : n
}

async function geocodeAddress(address: string) {
  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(address)}&format=json&limit=1`
    const resp = await fetch(url, { headers: { Accept: 'application/json' } })
    if (!resp.ok) return null
    const data = await resp.json()
    if (!data.length) return null
    const lat = Number(data[0].lat)
    const lon = Number(data[0].lon)
    if (Number.isNaN(lat) || Number.isNaN(lon)) return null
    return { lat, lon }
  } catch (err) {
    return null
  }
}

/* ── Field Display Component ─────────────────────────────── */
function ProfileField({ label, value, fullWidth = false }: { label: string; value: string; fullWidth?: boolean }) {
  return (
    <div className={fullWidth ? 'sm:col-span-2' : ''}>
      <div className="text-[10px] font-bold uppercase tracking-widest text-white/25 mb-1">{label}</div>
      <div className="text-sm font-medium text-white/90 bg-white/03 border border-white/05 rounded-xl px-4 py-3 min-h-[44px] flex items-center">
        {value}
      </div>
    </div>
  )
}

export function NgoProfilePage() {
  const navigate = useNavigate()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [uid, setUid] = useState<string>('')
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [form, setForm] = useState<ProfileForm>({
    ngoName: '',
    email: '',
    phone: '',
    serviceArea: '',
    capacity: '',
    description: '',
    photoDataUrl: '',
  })
  const [acceptedPosts, setAcceptedPosts] = useState<AcceptedPost[]>([])

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        navigate('/login')
        return
      }
      setUid(user.uid)
      setLoading(true)
      try {
        const userSnap = await getDoc(doc(db, 'users', user.uid))
        const d = userSnap.data() as UserProfile | undefined
        const loadedProfile = d ?? { email: user.email ?? '' }
        
        const email = loadedProfile.email || user.email || ''
        const initialForm: ProfileForm = {
          ngoName: loadedProfile.ngoName || loadedProfile.name || '',
          email,
          phone: loadedProfile.phone || '',
          serviceArea: loadedProfile.serviceArea || loadedProfile.address || '',
          capacity: loadedProfile.capacity || '',
          description: loadedProfile.description || '',
          photoDataUrl: loadedProfile.photoDataUrl || '',
        }

        setProfile({ ...loadedProfile, email })
        setForm(initialForm)

        const acceptedSnap = await getDocs(
          query(collection(db, 'foodPosts'), where('acceptedBy', '==', user.uid)),
        )
        setAcceptedPosts(acceptedSnap.docs.map((ds) => ds.data() as AcceptedPost))
      } catch (err) {
        toast.error(err instanceof Error ? err.message : 'Failed to load profile')
      } finally {
        setLoading(false)
      }
    })
    return () => unsub()
  }, [navigate])

  const stats = useMemo(() => {
    const totalAccepted = acceptedPosts.length
    const totalMeals = acceptedPosts.reduce((sum, p) => sum + parseMeals(p.quantity), 0)
    const collected = acceptedPosts.filter((p) => p.status === 'collected').length
    return { totalAccepted, totalMeals, collected }
  }, [acceptedPosts])

  function onFieldChange(field: keyof ProfileForm, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  async function onPhotoChange(file: File | null) {
    if (!file) return
    if (file.size > 2 * 1024 * 1024) {
      toast.error('Image too large (max 2MB)')
      return
    }
    const reader = new FileReader()
    reader.onload = () => {
      const result = typeof reader.result === 'string' ? reader.result : ''
      setForm((prev) => ({ ...prev, photoDataUrl: result }))
    }
    reader.readAsDataURL(file)
  }

  function onCancelEdit() {
    if (!profile) return
    setForm({
      ngoName: profile.ngoName || profile.name || '',
      email: profile.email || '',
      phone: profile.phone || '',
      serviceArea: profile.serviceArea || profile.address || '',
      capacity: profile.capacity || '',
      description: profile.description || '',
      photoDataUrl: profile.photoDataUrl || '',
    })
    setIsEditing(false)
  }

  async function onSaveProfile() {
    if (!uid) return
    if (!form.ngoName.trim()) return toast.error('NGO name is required')
    
    setSaving(true)
    try {
      const geo = await geocodeAddress(form.serviceArea.trim())
      
      const payload: any = {
        uid,
        role: 'ngo',
        ngoName: form.ngoName.trim(),
        name: form.ngoName.trim(),
        email: form.email,
        phone: form.phone.trim(),
        serviceArea: form.serviceArea.trim(),
        capacity: form.capacity.trim(),
        description: form.description.trim(),
        address: form.serviceArea.trim(),
        photoDataUrl: form.photoDataUrl || '',
        updatedAt: new Date().toISOString(),
      };
      
      if (geo) {
          payload.latitude = geo.lat;
          payload.longitude = geo.lon;
      }

      await setDoc(doc(db, 'users', uid), payload, { merge: true });
      await setDoc(doc(db, 'ngoProfiles', uid), payload, { merge: true });
      
      setProfile({
        ...payload,
      })
      setIsEditing(false)
      toast.success('Profile saved!')
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to direct save')
    } finally {
      setSaving(false)
    }
  }

  return (
    <NGOSidebarLayout title="Profile">
      <div className="mx-auto w-full max-w-5xl space-y-6">
        
        {loading ? (
          <div className="flex items-center gap-3 p-8 card-surface">
            <Spinner size="sm" />
            <span className="text-sm text-white/40">Fetching profile data...</span>
          </div>
        ) : isEditing ? (
          /* ── Edit State ──────────────────────────────── */
          <section className="card-surface p-6 md:p-8 animate-fade-in">
            <div className="flex items-center justify-between mb-8 border-b border-white/05 pb-6">
               <h2 className="text-xl font-bold text-white">Edit NGO Profile</h2>
               <div className="text-[10px] font-bold uppercase tracking-widest text-white/20 italic">NGO Settings</div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <label className="block">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">NGO Name</div>
                <input
                  type="text"
                  value={form.ngoName}
                  onChange={(e) => onFieldChange('ngoName', e.target.value)}
                  className="glass-input"
                  placeholder="e.g. SaveTheFood NGO"
                />
              </label>
              <label className="block">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Email (Read Only)</div>
                <input
                  type="text"
                  value={form.email}
                  readOnly
                  className="glass-input opacity-40 cursor-not-allowed"
                />
              </label>
              <label className="block">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Phone Number</div>
                <input
                  type="text"
                  value={form.phone}
                  onChange={(e) => onFieldChange('phone', e.target.value)}
                  className="glass-input"
                  placeholder="+1 (555) 000-0000"
                />
              </label>
              <label className="block">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Capacity (meals/day)</div>
                <input
                  type="text"
                  value={form.capacity}
                  onChange={(e) => onFieldChange('capacity', e.target.value)}
                  className="glass-input"
                  placeholder="e.g. 200"
                />
              </label>
              <label className="block md:col-span-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Service Area (Address)</div>
                <input
                  type="text"
                  value={form.serviceArea}
                  onChange={(e) => onFieldChange('serviceArea', e.target.value)}
                  className="glass-input"
                  placeholder="Street name, City, State"
                />
                <p className="mt-1.5 text-[10px] text-white/20 italic ml-1">This is used to match you with nearby food surplus.</p>
              </label>
              <label className="block md:col-span-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-2 ml-1">Mission Description</div>
                <textarea
                  value={form.description}
                  onChange={(e) => onFieldChange('description', e.target.value)}
                  className="glass-input min-h-[100px] resize-none"
                  placeholder="Tell us a bit about your mission..."
                />
              </label>

              <div className="md:col-span-2 border-t border-white/05 pt-6 mt-2">
                <div className="text-[10px] font-bold uppercase tracking-widest text-white/30 mb-4 ml-1">Profile Visuals</div>
                <div className="flex items-center gap-6">
                   <div className="relative group">
                     {form.photoDataUrl ? (
                         <img src={form.photoDataUrl} className="h-20 w-20 rounded-2xl object-cover ring-2 ring-purple-500/30" />
                     ) : (
                         <div className="h-20 w-20 rounded-2xl bg-white/05 border border-dashed border-white/10 grid place-items-center text-2xl">📸</div>
                     )}
                     {form.photoDataUrl && (
                        <button 
                           onClick={() => setForm(p => ({...p, photoDataUrl: ''}))}
                           className="absolute -top-2 -right-2 bg-red-500 h-6 w-6 rounded-full text-[10px] grid place-items-center shadow-lg transform group-hover:scale-110 transition-transform">✕</button>
                     )}
                   </div>
                   <label className="flex-1 cursor-pointer group">
                      <div className="glass-input flex items-center justify-center gap-2 text-sm text-white/40 group-hover:text-white/60 group-hover:bg-white/08 transition-all">
                        <span className="text-lg">📁</span>
                        {form.photoDataUrl ? 'Change Photo' : 'Upload NGO Logo'}
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => void onPhotoChange(e.target.files?.[0] ?? null)} />
                      </div>
                   </label>
                </div>
              </div>
            </div>

            <div className="mt-10 flex items-center gap-4">
              <button
                onClick={() => void onSaveProfile()}
                disabled={saving}
                className="cta-btn px-8 py-3 font-bold text-sm min-w-[140px]"
              >
                {saving ? 'Processing...' : 'Save Settings'}
              </button>
              <button
                onClick={onCancelEdit}
                className="soft-btn px-6 py-3 font-medium text-sm"
              >
                Discard
              </button>
            </div>
          </section>
        ) : (
          /* ── View State ──────────────────────────────── */
          <section className="animate-fade-in space-y-6">
            <div className="card-surface p-8 flex flex-col md:flex-row gap-8 items-start md:items-center relative overflow-hidden group">
               {/* Background Glow */}
               <div className="absolute -top-24 -right-24 h-64 w-64 bg-purple-600/10 blur-[100px] rounded-full pointer-events-none" />
               
               <div className="relative shrink-0">
                  {profile?.photoDataUrl ? (
                    <img src={profile.photoDataUrl} className="h-28 w-28 rounded-3xl object-cover ring-4 ring-white/05 shadow-2xl" />
                  ) : (
                    <div className="h-28 w-28 rounded-3xl bg-gradient-to-br from-purple-600/20 to-purple-800/20 ring-4 ring-white/05 shadow-2xl grid place-items-center text-4xl">🤝</div>
                  )}
                  <div className="absolute -bottom-2 -right-2 h-8 w-8 rounded-xl bg-purple-600 grid place-items-center shadow-xl border-2 border-[#09090b]">
                    <span className="text-xs">✓</span>
                  </div>
               </div>

               <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-3">
                     <h2 className="text-3xl font-extrabold text-white tracking-tight">{profile?.ngoName || profile?.name || 'NGO Partner'}</h2>
                     <span className="badge badge-purple px-3 py-1 text-[10px]">Verified NGO</span>
                  </div>
                  <p className="text-white/40 font-medium">{profile?.email}</p>
                  <p className="text-sm text-white/60 max-w-xl leading-relaxed italic border-l-2 border-purple-500/30 pl-4 py-1">
                    "{profile?.description || 'No mission statement provided yet.'}"
                  </p>
               </div>

               <button
                 onClick={() => setIsEditing(true)}
                 className="md:self-start bg-white/05 hover:bg-white/10 text-white/70 hover:text-white px-5 py-2.5 rounded-2xl border border-white/10 transition-all font-semibold text-xs flex items-center gap-2"
               >
                 <span>⚙️</span> Edit Profile
               </button>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
              <ProfileField label="Primary Phone" value={profile?.phone || 'Not provided'} />
              <ProfileField label="Active Reach" value={profile?.serviceArea || profile?.address || 'City-wide'} />
              <ProfileField label="Storage Limit" value={profile?.capacity ? `${profile.capacity} meals` : 'Not set'} />
            </div>

            <div className="grid gap-6 md:grid-cols-3 pt-4">
              <div className="glass-stats-card p-6 border-l-4 border-purple-500/50">
                  <div className="text-xs font-bold uppercase tracking-widest text-white/30 mb-1">Total Impact</div>
                  <div className="text-4xl font-black text-white">{stats.totalAccepted}</div>
                  <div className="text-[10px] font-medium text-white/20 mt-2">Posts successfully matched</div>
              </div>
              <div className="glass-stats-card p-6 border-l-4 border-blue-500/50">
                  <div className="text-xs font-bold uppercase tracking-widest text-white/30 mb-1">Nutrition Saved</div>
                  <div className="text-4xl font-black text-white">{stats.totalMeals}</div>
                  <div className="text-[10px] font-medium text-white/20 mt-2">Estimated meals distributed</div>
              </div>
              <div className="glass-stats-card p-6 border-l-4 border-emerald-500/50">
                  <div className="text-xs font-bold uppercase tracking-widest text-white/30 mb-1">Success Rate</div>
                  <div className="text-4xl font-black text-white">{stats.collected}</div>
                  <div className="text-[10px] font-medium text-white/20 mt-2">Total collections verified</div>
              </div>
            </div>
          </section>
        )}

      </div>
    </NGOSidebarLayout>
  )
}
