import type { ReactNode } from 'react'
import { onAuthStateChanged } from 'firebase/auth'
import { AnimatePresence, motion } from 'framer-motion'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { auth } from './lib/firebase'
import { type SignupRole, getDashboardPathByRole, getUserRole } from './lib/rbac'
import { AdminDashboard } from './pages/AdminDashboard'
import { AdminPostsPage } from './pages/AdminPostsPage'
import { AdminUsersPage } from './pages/AdminUsersPage'
import { AuthPage } from './pages/AuthPage'
import { ContactUs } from './pages/ContactUs.jsx'
import { HomePage } from './pages/HomePage'
import { NgoActivityPage } from './pages/NgoActivityPage'
import { NgoProfilePage } from './pages/NgoProfilePage'
import { NGODashboard } from './pages/NGODashboard'
import { RestaurantDashboard } from './pages/RestaurantDashboard'
import { RestaurantOverviewPage } from './pages/RestaurantOverviewPage'
import { RestaurantPostsPage } from './pages/RestaurantPostsPage'
import { RestaurantProfilePage } from './pages/RestaurantProfilePage'
import { SelectRolePage } from './pages/SelectRolePage'

function RoleProtectedRoute({ role, element }: { role: SignupRole; element: ReactNode }) {
  const [state, setState] = useState<{ loading: boolean; allowed: boolean; redirectTo: string }>({
    loading: true,
    allowed: false,
    redirectTo: '/login',
  })

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user: any) => {
      if (!user) {
        setState({ loading: false, allowed: false, redirectTo: '/login' })
        return
      }

      const userRole = await getUserRole(user.uid)
      if (!userRole) {
        setState({ loading: false, allowed: false, redirectTo: '/select-role' })
        return
      }

      if (userRole !== role) {
        toast.error('Access denied - wrong role')
        setState({
          loading: false,
          allowed: false,
          redirectTo: getDashboardPathByRole(userRole),
        })
        return
      }

      setState({ loading: false, allowed: true, redirectTo: '' })
    })

    return () => unsub()
  }, [role])

  if (state.loading) {
    return <div className="p-6 text-sm text-white/40">Checking access...</div>
  }
  if (!state.allowed) return <Navigate to={state.redirectTo} replace />
  return element
}

export function App() {
  const location = useLocation()

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.25 }}
      >
        <Routes location={location}>
          <Route path="/" element={<HomePage />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/login" element={<AuthPage />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/select-role" element={<SelectRolePage />} />
          <Route
            path="/restaurant"
            element={<RoleProtectedRoute role="restaurant" element={<RestaurantDashboard />} />}
          />
          <Route
            path="/restaurant/dashboard"
            element={<RoleProtectedRoute role="restaurant" element={<RestaurantOverviewPage />} />}
          />
          <Route
            path="/restaurant/posts"
            element={<RoleProtectedRoute role="restaurant" element={<RestaurantPostsPage />} />}
          />
          <Route
            path="/restaurant/profile"
            element={<RoleProtectedRoute role="restaurant" element={<RestaurantProfilePage />} />}
          />
          <Route path="/ngo" element={<RoleProtectedRoute role="ngo" element={<NGODashboard />} />} />
          <Route
            path="/ngo/activity"
            element={<RoleProtectedRoute role="ngo" element={<NgoActivityPage />} />}
          />
          <Route
            path="/ngo/profile"
            element={<RoleProtectedRoute role="ngo" element={<NgoProfilePage />} />}
          />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/posts" element={<AdminPostsPage />} />
          <Route path="/admin/users" element={<AdminUsersPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </motion.div>
    </AnimatePresence>
  )
}

