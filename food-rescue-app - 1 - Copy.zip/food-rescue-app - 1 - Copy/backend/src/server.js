require('dotenv').config()
const express = require('express')
const cors = require('cors')
const { initializeApp, getApps } = require('firebase-admin/app')
const { getFirestore } = require('firebase-admin/firestore')
const foodExpiryHours = require('./foodExpiry')


const app = express()

if (!getApps().length) {
  initializeApp()
}
const db = getFirestore()

app.use(
  cors({
    origin: ['http://localhost:5174', 'http://localhost:5173'],
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  }),
)
app.use(express.json({ limit: '5mb' }))

app.get('/health', (req, res) => {
  res.json({ ok: true, name: 'Zero Hunger API' })
})

function toNumberOrNull(value) {
  const n = Number(value)
  return Number.isNaN(n) ? null : n
}

function haversineKm(aLat, aLng, bLat, bLng) {
  const R = 6371
  const dLat = ((bLat - aLat) * Math.PI) / 180
  const dLng = ((bLng - aLng) * Math.PI) / 180
  const aa =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((aLat * Math.PI) / 180) *
      Math.cos((bLat * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2
  const c = 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa))
  return R * c
}

app.post('/api/match', async (req, res) => {
  try {
    const foodPost = req.body?.foodPost
    if (!foodPost) {
      return res.status(400).json({ error: 'Missing foodPost in request body' })
    }

    let ngoList = []
    try {
      const ngoSnap = await db.collection('ngoProfiles').get()
      ngoList = ngoSnap.docs.map((d) => ({ id: d.id, ...d.data() }))
    } catch (fetchErr) {
      console.error('[api/match] Firestore read failed:', fetchErr)
      return res.json({ bestMatch: 'Error', bestNgo: null, reason: 'Database error' })
    }

    if (!ngoList.length) {
      return res.json({ bestMatch: 'No NGOs', bestNgo: null, reason: 'No registered NGOs found' })
    }

    // Advanced Geocoding Fallback for Post
    let postLat = toNumberOrNull(foodPost.latitude)
    let postLng = toNumberOrNull(foodPost.longitude)
    
    if ((postLat === null || postLng === null) && foodPost.pickupAddress) {
       console.log('[api/match] Post missing coords, attempting geocode:', foodPost.pickupAddress)
       try {
         const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(foodPost.pickupAddress)}&format=json&limit=1`
         const resp = await fetch(url, { headers: { 'User-Agent': 'ZeroHungerBot/1.0' } })
         const data = await resp.json()
         if (data && data[0]) {
           postLat = Number(data[0].lat)
           postLng = Number(data[0].lon)
           console.log(`[api/match] Geocoded post: ${postLat}, ${postLng}`)
         }
       } catch (geoErr) {
         console.error('[api/match] Post geocode failed:', geoErr.message)
       }
    }

    const postQuantity = parseInt(String(foodPost.quantity).replace(/[^0-9]/g, ''), 10) || 1
    const isCritical = foodPost.riskLevel === 'CRITICAL' || foodPost.riskLevel === 'HIGH'
    const declinedList = Array.isArray(foodPost.declinedByNgos) ? foodPost.declinedByNgos : []

    const scored = await Promise.all(ngoList.map(async (ngo) => {
      if (declinedList.includes(ngo.id)) return { ngo, score: -1000 }

      let ngoLat = toNumberOrNull(ngo.latitude)
      let ngoLng = toNumberOrNull(ngo.longitude)

      // Advanced Geocoding Fallback for NGO
      if ((ngoLat === null || ngoLng === null) && (ngo.address || ngo.serviceArea)) {
        try {
          const addr = ngo.address || ngo.serviceArea
          console.log(`[api/match] NGO ${ngo.id} missing coords, geocoding: ${addr}`)
          const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(addr)}&format=json&limit=1`
          const resp = await fetch(url, { headers: { 'User-Agent': 'ZeroHungerBot/1.0' } })
          const data = await resp.json()
          if (data && data[0]) {
            ngoLat = Number(data[0].lat)
            ngoLng = Number(data[0].lon)
          }
        } catch (e) { /* ignore */ }
      }

      const distanceKm = 
         postLat !== null && postLng !== null && ngoLat !== null && ngoLng !== null
            ? haversineKm(postLat, postLng, ngoLat, ngoLng)
            : 50; // Neutral distance if both can't be geocoded

      let score = 100
      const distancePenalty = isCritical ? distanceKm * 5 : distanceKm * 2
      score -= distancePenalty

      const ngoCapacity = parseInt(String(ngo.capacity).replace(/[^0-9]/g, ''), 10) || 50
      if (postQuantity > ngoCapacity) score -= 40
      else if (postQuantity <= ngoCapacity / 2) score += 15

      return { ngo, distanceKm, score }
    }))

    scored.sort((a, b) => b.score - a.score)
    const best = scored[0]

    if (best.score < -500) {
      return res.json({ bestMatch: 'Public Board', bestNgo: null, reason: 'All candidates unsuitable' })
    }

    const ngoName = best.ngo.ngoName || best.ngo.name || best.ngo.id
    const reason = `Automated Match | Dist: ${best.distanceKm.toFixed(1)}km | Score: ${Math.round(best.score)}`
    
    console.log(`[api/match] Strategy: SMART | Winner: ${ngoName} (${best.ngo.id}) | Score: ${best.score}`)

    return res.json({ bestMatch: ngoName, bestNgo: { ...best.ngo, id: best.ngo.id }, reason })
  } catch (err) {
    console.error('[api/match] Severe internal error:', err)
    return res.status(500).json({ error: 'Internal Match Failure' })
  }
})


app.post('/api/predict-expiry', async (req, res) => {
  // eslint-disable-next-line no-console
  console.log('GEMINI_API_KEY exists:', !!process.env.GEMINI_API_KEY)
  // eslint-disable-next-line no-console
  console.log('GEMINI_API_KEY value:', process.env.GEMINI_API_KEY?.substring(0, 10))

  try {
    const { foodName, quantity, postedTime, expiryTime } = req.body
    if (!foodName || !quantity || !postedTime || !expiryTime) {
      return res.status(400).json({ error: 'Missing required fields' })
    }

    const expiryDate = new Date(expiryTime)
    const msLeft = expiryDate.getTime() - Date.now()
    const hoursLeft = Math.max(0, msLeft / (1000 * 60 * 60)).toFixed(1)

    const prompt = `You are a food safety expert. Given this food post:
             - Food: ${foodName}
             - Quantity: ${quantity}
             - Hours remaining: ${hoursLeft}
             Respond in JSON only, no extra text:
             {
               "riskLevel": "LOW" or "MEDIUM" or "HIGH" or "CRITICAL",
               "reason": "one line explanation",
               "recommendation": "one line action",
               "safeHours": number
             }`
    
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
        }),
      }
    )

    if (!response.ok) {
        throw new Error(`Gemini API error: ${response.status}`)
    }

    const responseText = await response.text()
    const data = JSON.parse(responseText)
    const text = data.candidates[0].content.parts[0].text
    const cleaned = text.replace(/```json|```/g, '').trim()
    const parsed = JSON.parse(cleaned)
    return res.json(parsed)
  } catch (error) {
    console.error('Predict expiry error, using advanced math fallback:', error instanceof Error ? error.message : 'Unknown Error')
    await new Promise(r => setTimeout(r, 800)); // Demo delay

    const { foodName, cookedTime, expiryTime, quantity } = req.body;
    const name = (foodName || '').toLowerCase();
    
    const cookedDate = new Date(cookedTime);
    const userExpiryDate = new Date(expiryTime);
    const now = new Date();

    // 1. Calculate how long ago it was cooked
    const hoursSinceCooked = Math.max(0, (now.getTime() - cookedDate.getTime()) / (1000 * 60 * 60));
    
    // 2. Calculate hours until user says it expires
    const userHoursRemaining = Math.max(0.1, (userExpiryDate.getTime() - now.getTime()) / (1000 * 60 * 60));
    
    const quantityNum = parseInt(quantity) || 1;

    // Perishability Weights
    let safetyThreshold = 12; // Most food shouldn't be donated after 12h of being cooked
    let perishabilityKey = 2;

    if (name.match(/meat|chicken|fish|seafood|beef/)) {
        safetyThreshold = 6;
        perishabilityKey = 5;
    } else if (name.match(/milk|dairy|curd|cream/)) {
        safetyThreshold = 8;
        perishabilityKey = 4;
    } else if (name.match(/rice|biryani|pasta/)) {
        safetyThreshold = 10;
        perishabilityKey = 3;
    }

    // AI Prediction: Time Since Cooked + Remaining should be < safetyThreshold
    const totalLifeSpanHours = hoursSinceCooked + userHoursRemaining;
    const isSafeComparison = totalLifeSpanHours <= safetyThreshold;

    const quantityWeight = Math.log10(Math.max(1, quantityNum)) + 1;
    const riskScore = (perishabilityKey * quantityWeight) / userHoursRemaining;

    let riskLevel = 'LOW';
    let recommendation = 'Safe for standard distribution';
    let reason = `${foodName} recorded. Data confirms safe timeline.`;

    // Safety Alert Logic
    if (!isSafeComparison) {
        riskLevel = 'CRITICAL';
        recommendation = 'DO NOT DISTRIBUTE - SAFETY MISMATCH';
        reason = `WARNING: User provided expiry (${totalLifeSpanHours.toFixed(1)}h total) exceeds AI safety benchmark (${safetyThreshold}h) for ${name}.`;
    } else if (riskScore > 8 || userHoursRemaining < 2) {
        riskLevel = 'HIGH';
        recommendation = 'Pickup within 60 mins';
        reason = `Rapid consumption needed. Cooked ${hoursSinceCooked.toFixed(1)}h ago.`;
    } else if (riskScore > 3) {
        riskLevel = 'MEDIUM';
        recommendation = 'Distribute within 3 hours';
        reason = `Moderately fresh. Cooked ${hoursSinceCooked.toFixed(1)}h ago.`;
    }

    return res.json({
        riskLevel,
        reason: `🤖 [Safety Audit] ${reason}`,
        recommendation,
        safeHours: Math.min(userHoursRemaining, safetyThreshold - hoursSinceCooked).toFixed(1)
    });
  }
})

app.post('/api/predict-cooking-expiry', (req, res) => {
  try {
    const { foodName, cookingTime } = req.body;
    if (!foodName || !cookingTime) {
      return res.status(400).json({ error: 'Missing foodName or cookingTime' });
    }

    const now = new Date();
    const cookingDate = new Date();
    const [hours, minutes] = cookingTime.split(':').map(Number);
    cookingDate.setHours(hours, minutes, 0, 0);

    const lowerName = foodName.toLowerCase();
    let matchedHours = foodExpiryHours['default'];
    
    for (const key in foodExpiryHours) {
      if (lowerName.includes(key)) {
        matchedHours = foodExpiryHours[key];
        break;
      }
    }

    const expiryTimeBase = new Date(cookingDate.getTime() + matchedHours * 60 * 60 * 1000);
    const hoursLeft = (expiryTimeBase.getTime() - now.getTime()) / (1000 * 60 * 60);

    let riskLevel, reason, recommendation;

    if (hoursLeft < 0) {
      riskLevel = 'CRITICAL';
      reason = 'Food has already expired';
      recommendation = 'Do not distribute - discard immediately';
    } else if (hoursLeft < 1) {
      riskLevel = 'CRITICAL';
      reason = `Only ${Math.round(hoursLeft * 60)} minutes remaining`;
      recommendation = 'Contact nearest NGO immediately for urgent pickup';
    } else if (hoursLeft < 2) {
      riskLevel = 'HIGH';
      reason = `Less than 2 hours remaining for ${foodName}`;
      recommendation = 'Notify NGO now - pickup needed within 1 hour';
    } else if (hoursLeft < 4) {
      riskLevel = 'MEDIUM';
      reason = `${Math.round(hoursLeft)} hours remaining - plan pickup soon`;
      recommendation = 'Schedule NGO pickup within next 2 hours';
    } else {
      riskLevel = 'LOW';
      reason = `${Math.round(hoursLeft)} hours remaining - food is fresh`;
      recommendation = 'No urgent action needed - monitor regularly';
    }

    const safeUntil = new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(expiryTimeBase);

    if (hoursLeft > 0 && riskLevel === 'LOW') {
      reason = `${foodName || 'Food'} is safe for ${matchedHours} hours after cooking`;
    }

    res.json({
      expiryTime: expiryTimeBase.toISOString(),
      expiryHours: matchedHours,
      riskLevel,
      reason,
      recommendation,
      safeUntil,
      safeHours: hoursLeft > 0 ? Number(hoursLeft.toFixed(1)) : 0
    });
  } catch (error) {
    console.error('Cooking expiry predict error:', error.message);
    res.status(500).json({ error: error.message });
  }
})

app.post('/api/food-safety-score', async (req, res) => {
  try {
    const { foodName, quantity, cookingTime, lat, lng } = req.body;
    if (!foodName || !cookingTime) {
      return res.status(400).json({ error: 'Missing foodName or cookingTime' });
    }

    const now = new Date();
    const cookingDate = new Date();
    const [hours, minutes] = cookingTime.split(':').map(Number);
    cookingDate.setHours(hours, minutes, 0, 0);

    const lowerName = foodName.toLowerCase();
    let matchedHours = foodExpiryHours['default'];
    
    for (const key in foodExpiryHours) {
      if (lowerName.includes(key)) {
        matchedHours = foodExpiryHours[key];
        break;
      }
    }

    const expiryTimeBase = new Date(cookingDate.getTime() + matchedHours * 60 * 60 * 1000);
    const hoursLeft = (expiryTimeBase.getTime() - now.getTime()) / (1000 * 60 * 60);

    let weatherScore = 7; // default fallback
    let currentTemp = null;
    let weatherCondition = 'Unknown';

    if (lat !== undefined && lng !== undefined && lat !== null && lng !== null) {
      try {
        const weatherResponse = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current_weather=true`
        );
        const weatherData = await weatherResponse.json();
        currentTemp = weatherData.current_weather?.temperature;
        
        if (currentTemp > 35) {
          weatherScore = 3;
          weatherCondition = 'Very Hot';
        } else if (currentTemp > 30) {
          weatherScore = 5;
          weatherCondition = 'Hot';
        } else if (currentTemp > 25) {
          weatherScore = 7;
          weatherCondition = 'Warm';
        } else if (currentTemp > 20) {
          weatherScore = 8;
          weatherCondition = 'Moderate';
        } else {
          weatherScore = 10;
          weatherCondition = 'Cool';
        }
      } catch (err) {
        console.log('Weather fetch failed, using default:', err.message);
        // fallback to month-based if weather API fails
        const month = new Date().getMonth();
        if (month >= 3 && month <= 6) weatherScore = 5;
        else if (month >= 7 && month <= 9) weatherScore = 6;
        else weatherScore = 8;
      }
    }

    const foodRiskScore = Math.min(10, Math.max(1, Math.round(matchedHours / 2 + 2)));
    let timeScore = 0;
    if (hoursLeft > 4) timeScore = 10;
    else if (hoursLeft > 0) timeScore = Math.round((hoursLeft / 4) * 10);
    const quantityScore = 8;
    
    const finalScore = Math.round((foodRiskScore + timeScore + weatherScore + quantityScore) / 4);
    
    let safetyLabel = 'Low Risk';
    let safetyColor = 'green';
    let recommendation = 'Food is stable - distribute normally.';
    
    if (hoursLeft < 0) {
       safetyLabel = 'CRITICAL Risk - EXPIRED';
       safetyColor = 'red';
       recommendation = 'Do not distribute. Discard immediately.';
    } else if (finalScore <= 4 || hoursLeft < 1) {
       safetyLabel = 'CRITICAL Risk';
       safetyColor = 'red';
       recommendation = 'Urgent! Find NGO immediately. Quality degrading fast.';
    } else if (finalScore <= 6 || hoursLeft < 2) {
       safetyLabel = 'High Risk';
       safetyColor = 'orange';
       recommendation = 'Distribute within 1-2 hours. Keep refrigerated.';
    } else if (finalScore <= 8) {
       safetyLabel = 'Medium Risk';
       safetyColor = 'yellow';
       recommendation = 'Monitor food temperature during transport.';
    }

    const safeUntil = new Intl.DateTimeFormat('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    }).format(expiryTimeBase);

    res.json({
      score: finalScore,
      safetyLabel,
      safetyColor,
      recommendation,
      safeUntil,
      expiryTime: expiryTimeBase.toISOString(),
      weatherInfo: {
        temperature: currentTemp,
        condition: weatherCondition,
        impact: currentTemp > 30 ? 'High temperature reducing food safety score' : 'Temperature is favorable'
      },
      breakdown: {
        foodTypeScore: foodRiskScore,
        timeScore,
        weatherScore,
        quantityScore
      }
    });

  } catch (err) {
    console.error('Food safety score error:', err.message);
    res.status(500).json({ error: err.message });
  }
})


const port = Number(process.env.PORT || 5000)
app.listen(port, () => {
  // eslint-disable-next-line no-console
  console.log(`Zero Hunger API listening on http://localhost:${port}`)
})

