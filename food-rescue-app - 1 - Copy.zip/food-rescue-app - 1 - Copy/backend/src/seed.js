require('dotenv').config();
const admin = require('firebase-admin');
const path = require('path');

// Initialize Firebase Admin
try {
  const serviceAccount = require('../serviceAccount.json');
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
} catch (e) {
  console.log("Firebase Admin Init Failed:", e);
  process.exit(1);
}

const db = admin.firestore();
const auth = admin.auth();

async function deleteCollection(collectionPath, batchSize) {
  const collectionRef = db.collection(collectionPath);
  const query = collectionRef.orderBy('__name__').limit(batchSize);

  return new Promise((resolve, reject) => {
    deleteQueryBatch(query, resolve).catch(reject);
  });
}

async function deleteQueryBatch(query, resolve) {
  const snapshot = await query.get();

  const batchSize = snapshot.size;
  if (batchSize === 0) {
    resolve();
    return;
  }

  const batch = db.batch();
  snapshot.docs.forEach((doc) => {
    batch.delete(doc.ref);
  });
  await batch.commit();

  process.nextTick(() => {
    deleteQueryBatch(query, resolve);
  });
}

async function clearAuthUsers() {
  let listUsersResult;
  do {
    listUsersResult = await auth.listUsers(1000);
    const uids = listUsersResult.users.map((userRecord) => userRecord.uid);
    if (uids.length > 0) {
      await auth.deleteUsers(uids);
      console.log(`Deleted ${uids.length} auth users.`);
    }
  } while (listUsersResult.pageToken);
}

async function seed() {
  try {
    console.log("Clearing existing data...");
    await clearAuthUsers();
    await deleteCollection('users', 500);
    await deleteCollection('ngoProfiles', 500);
    await deleteCollection('foodPosts', 500);
    await deleteCollection('restaurantFeedbacks', 500);
    console.log("Data cleared.");

    console.log("Creating new seed users...");

    // 1. Restaurant
    const restUser = await auth.createUser({
      email: 'restaurant@test.com',
      password: 'password123',
      displayName: 'Central Kitchen',
    });
    await db.collection('users').doc(restUser.uid).set({
      uid: restUser.uid,
      email: 'restaurant@test.com',
      role: 'restaurant',
      name: 'Central Kitchen',
      phone: '1112223333',
      address: 'Adyar, Chennai',
      createdAt: new Date().toISOString()
    });

    // 2. High Priority NGO (Close location, high capacity)
    const ngo1User = await auth.createUser({
      email: 'ngo1@test.com',
      password: 'password123',
      displayName: 'Chennai Relief NGO',
    });
    const ngo1Data = {
      uid: ngo1User.uid,
      email: 'ngo1@test.com',
      role: 'ngo',
      name: 'Chennai Relief NGO',
      ngoName: 'Chennai Relief NGO',
      phone: '9998887777',
      serviceArea: 'Chennai, Tamil Nadu',
      address: 'Chennai, Tamil Nadu',
      capacity: '500', 
      latitude: 13.0827, // Chennai coords
      longitude: 80.2707,
      createdAt: new Date().toISOString()
    };
    await db.collection('users').doc(ngo1User.uid).set(ngo1Data);
    await db.collection('ngoProfiles').doc(ngo1User.uid).set(ngo1Data);

    // 3. Lower Priority NGO (Lower capacity, slightly further away conceptually if needed, or simply lower capacity to show routing logic)
    const ngo2User = await auth.createUser({
      email: 'ngo2@test.com',
      password: 'password123',
      displayName: 'Local Shelter',
    });
    const ngo2Data = {
      uid: ngo2User.uid,
      email: 'ngo2@test.com',
      role: 'ngo',
      name: 'Local Shelter',
      ngoName: 'Local Shelter',
      phone: '4445556666',
      serviceArea: 'Velachery, Chennai',
      address: 'Velachery, Chennai',
      capacity: '20', 
      latitude: 12.9815, // Velachery coords
      longitude: 80.2180,
      createdAt: new Date().toISOString()
    };
    await db.collection('users').doc(ngo2User.uid).set(ngo2Data);
    await db.collection('ngoProfiles').doc(ngo2User.uid).set(ngo2Data);

    console.log("Successfully seeded!");
    process.exit(0);
  } catch (error) {
    console.error("Error during seed:", error);
    process.exit(1);
  }
}

seed();
