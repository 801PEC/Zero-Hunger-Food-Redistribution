const foodExpiryHours = {
  // Rice dishes
  'rice': 4, 'biryani': 4, 'fried rice': 3, 'tomato rice': 4,
  'curd rice': 3, 'lemon rice': 5, 'pulao': 4,
  
  // Bread/Roti
  'chapathi': 6, 'roti': 6, 'paratha': 5, 'naan': 4, 'puri': 3,
  'idli': 6, 'dosa': 3, 'vada': 4, 'uttapam': 4,
  
  // Curries & Gravies
  'sambar': 5, 'rasam': 5, 'dal': 5, 'curry': 4,
  'chicken curry': 4, 'fish curry': 3, 'mutton curry': 4,
  'paneer': 4, 'rajma': 5, 'chole': 5,
  
  // Snacks
  'pakoda': 3, 'bajji': 3, 'bonda': 3, 'samosa': 4,
  'sandwich': 3, 'burger': 3,
  
  // Sweets
  'payasam': 6, 'halwa': 8, 'ladoo': 24, 'barfi': 24,
  'cake': 24, 'kheer': 5,
  
  // Default
  'default': 4
};

module.exports = foodExpiryHours;
